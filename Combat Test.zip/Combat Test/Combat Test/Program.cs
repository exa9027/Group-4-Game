﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Combat_Test
{
    class Program
    {
        static void Main(string[] args)
        {
            Combat obj = new Combat();
            obj.GeneratePlayer(30, 10, 5, 3, 0);
            obj.GenerateEnemy("Steve", 15, 8, 1, 2);
            obj.PlayerAttack();
        }
    }
}
