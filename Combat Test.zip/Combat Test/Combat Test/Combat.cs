﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Combat_Test
{
    class Combat
    {
        public enum Enemies { Snake, GiantSpider, Manticore, Centaur, Goblin, Imp, Ogre, LesserDragon, Fuckup }
        Random rng = new Random();

        /*public CombatEnemy Enemy()
        {
            Enemies enemyType = (Enemies)rng.Next(0, 7);

            switch (enemyType)
            {
                case (Enemies.Snake):
                    return new CombatEnemy("Snake", 80, 30, 10, 12);
                case (Enemies.GiantSpider):
                    return new CombatEnemy("GiantSpider", 50, 50, 40, 18);
                case (Enemies.Manticore):
                    return new CombatEnemy("Manticore", 120, 60, 60, 24);
                case (Enemies.Centaur):
                    return new CombatEnemy("Centaur", 100, 80, 30, 24);
                case (Enemies.Goblin):
                    return new CombatEnemy("Goblin", 90, 60, 40, 16);
                case (Enemies.Imp):
                    return new CombatEnemy("Imp", 50, 90, 10, 20);
                case (Enemies.Ogre):
                    return new CombatEnemy("Ogre", 160, 70, 180, 34);
                case (Enemies.LesserDragon):
                    return new CombatEnemy("LesserDragon", 150, 100, 100, 38);
                default:
                    return new CombatEnemy("Fuckup", 9999999, 9999999, 9999999, 9999999);
            }
        }*/

        public CombatEnemy Enemy = new CombatEnemy("LesseDragon", 160, 70, 180, 34);

        public CombatPlayer Player = new CombatPlayer(200, 80, 80, 30, 0);

        public void PlayerAttack()
        {
            Console.WriteLine(Player);
            Console.WriteLine(Enemy);
            Console.WriteLine("Player attacks");
            Enemy.TakeDamage();
            Console.WriteLine(Enemy.Health);
            if (Enemy.IsDead() == true)
            {
                Console.WriteLine("Enemy is Dead");
                return;
            }

            Console.WriteLine("Enemy attacks");
            Player.TakeDamage();
            Console.WriteLine(Player.Health);
            if (Player.IsDead() == true)
            {
                Console.WriteLine("Player is dead");
                return;
            }
        }
    }
}
