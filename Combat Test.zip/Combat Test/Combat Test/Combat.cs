﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Combat_Test
{
    class Combat
    {
        public CombatEnemy Enemy;
        public CombatPlayer Player;

        public void GenerateEnemy(string name, int health, int attack, int defense, int power)
        {
            Enemy = new CombatEnemy(name, health, attack, defense, power);
        }

        public void GeneratePlayer(int health, int attack, int defense, int level, int experience)
        {
            Player = new CombatPlayer(health, attack, defense, level, experience);
        }

        public void PlayerAttack()
        {
            Console.WriteLine(Player);
            Console.WriteLine(Enemy);
            Console.WriteLine("Player attacks");
            Enemy.TakeDamage();
            if (Enemy.IsDead() == true)
            {
                Console.WriteLine("Enemy is Dead");
                int expYield = (200 * Enemy.power) / 7;
                Console.WriteLine("Player earns " + expYield + " experience points.");
                Player.Experience += expYield;
                return;
            }

            Console.WriteLine("Enemy attacks");
            Player.TakeDamage();
            if (Player.IsDead() == true)
            {
                Console.WriteLine("Player is dead");
                return;
            }
        }
    }
}
