﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Group4Game
{
    class FSM
    {
        public enum gameState
        {
            mainMenu,
            game,
            gameOver
        }
        public gameState state = gameState.mainMenu;
        public MouseState mouse;
        public Rectangle StartButtonRect;
        public Texture2D StartButton;
        public SpriteFont font;

        public FSM(Texture2D startButtonTex, SpriteFont fontOfChoice)
        {
            StartButton = startButtonTex;
            StartButtonRect = new Rectangle(400, 400, startButtonTex.Width, startButtonTex.Height);
            font = fontOfChoice;
        }

        public void FSMUpdate()
        {
            mouse = Mouse.GetState();
            switch (state)
            {
                case gameState.mainMenu:
                    if (StartButtonRect.Contains(mouse.Position))
                    {
                        if (mouse.LeftButton == ButtonState.Pressed)
                        {
                            state = gameState.game;
                        }
                    }
                    break;
                case gameState.game:
                    break;
            }
        }
        public void FSMDraw(SpriteBatch spritebatch)
        {
            mouse = Mouse.GetState();
            switch (state)
            {
                case gameState.mainMenu:
                    if (StartButtonRect.Contains(mouse.Position))
                    {
                        //spritebatch.Draw(StartButton, StartButtonRect, Color.White);
                        spritebatch.DrawString(font, "button", new Vector2(400, 400), Color.White);
                    }
                    else
                    {
                        //spritebatch.Draw(StartButton, StartButtonRect, Color.Red);
                        spritebatch.DrawString(font, "button", new Vector2(400, 400), Color.Red);


                    }
                    spritebatch.DrawString(
                        font,
                        "Mouse Position" + mouse.Position.X + ", " + mouse.Position.Y + "\n" + "Button Width: " + StartButtonRect.Width + "\n" + "Button Height: " + StartButtonRect.Height + "\n" + "Mouse in Rectangle: " + StartButtonRect.Contains(mouse.Position) + "\n" + "Rectangle X and Y: (" + StartButtonRect.X + ", " + StartButtonRect.Y + ")",
                        new Vector2(30, 30),
                        Color.OliveDrab);
                    break;
                    
            }
        }
    }
}
