﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group4Game
{
    class CombatInterface
    {
        Texture2D playerStatus;
        Texture2D enemyStatus;
        Texture2D hp;
        Texture2D xp;
        SpriteFont font;
        Rectangle playerStatusRect;
        Rectangle enemyStatusRect;
        Rectangle PlayerHpRect;
        Rectangle EnemyHpRect;
        Rectangle xpRect;

        int playerTotalHp; // i only put these fields in so i could show where each of these
        public int PlayerTotalHp
        {
            get { return playerTotalHp; }
            set { playerTotalHp = value; }
        }
        int playerCurrentHp; // would go in the code
        public int PlayerCurrentHp
        {
            get { return playerCurrentHp; }
            set { playerCurrentHp = value; }
        }
        int enemyTotalHp; // however you're getting the variables from the classes
        public int EnemyTotalHp
        {
            get { return enemyTotalHp; }
            set { enemyTotalHp = value; }
        }
        int enemyCurrentHp; // should be done in the draw method
        public int EnemyCurrentHp
        {
            get { return enemyCurrentHp; }
            set { enemyCurrentHp = value; }
        }

        int totalXp; // before any other logic
        public int TotalXp
        {
            get { return totalXp; }
            set { totalXp = value; }
        }
        int currentXp;

        public CombatInterface(Texture2D playerStatusBar, Texture2D enemyStatusBar, Texture2D hpBar, Texture2D xpBar, SpriteFont battleFont, int windowHeight, int windowWidth)
        {
            playerStatus = playerStatusBar;
            enemyStatus = enemyStatusBar;
            hp = hpBar;
            xp = xpBar;
            font = battleFont;
            playerStatusRect = new Rectangle(20, windowHeight - 20 - playerStatus.Height, playerStatus.Width, playerStatus.Height);
            enemyStatusRect = new Rectangle(windowWidth - 20 - enemyStatus.Width, 20, enemyStatus.Width, enemyStatus.Height);
            PlayerHpRect = new Rectangle(20 + 155, windowHeight + 50 - playerStatus.Height, hp.Width, hp.Height);
            EnemyHpRect = new Rectangle(windowWidth - 20 - enemyStatus.Width, 20, hp.Width, hp.Height);
            xpRect = new Rectangle(20 + 155, windowHeight + 110 - playerStatus.Height, xp.Width, xp.Height);
        }

        public void draw(SpriteBatch spriteBatch)
        {
            // get your values here

            double playerHPRatio = (double)playerCurrentHp / (double)playerTotalHp;
            int PlayerHpRectWidth = (int)Math.Round(playerHPRatio * hp.Width);
            PlayerHpRect = new Rectangle(PlayerHpRect.X, PlayerHpRect.Y, PlayerHpRectWidth, PlayerHpRect.Height);
            double enemyHPRatio = (double)enemyCurrentHp / (double)enemyTotalHp;
            int EnemyHpRectWidth = (int)Math.Round(enemyHPRatio * hp.Width);
            EnemyHpRect = new Rectangle(EnemyHpRect.X, EnemyHpRect.Y, EnemyHpRectWidth, EnemyHpRect.Height);
            double xpRatio = (double)currentXp / (double)totalXp;
            int xpWidth = (int)Math.Round(xpRatio * xp.Width);
            xpRect = new Rectangle(xpRect.X, xpRect.Y, xpWidth, xpRect.Height);


            spriteBatch.Draw(hp, PlayerHpRect, Color.White);
            spriteBatch.Draw(hp, EnemyHpRect, Color.White);
            spriteBatch.Draw(xp, xpRect, Color.White);
            spriteBatch.Draw(playerStatus, playerStatusRect, Color.White);
            spriteBatch.Draw(enemyStatus, enemyStatusRect, Color.White);

            // draw player level in the box at the bottom and enemy power level in the box at the top
            // you'll need to trial and error that b/c i don't have exact coords (sorry bout that)
        }
    }
}
