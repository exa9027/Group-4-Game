﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Combat
{
    class CombatEnemy
    {
        public string name;
        public int health;
        public int attack;
        public int defense;
        public int power;

        public CombatEnemy(string nm, int hp, int atk, int def, int pow)
        {
            name = nm;
            health = hp;
            attack = atk;
            defense = def;
            power = pow;
        }

        public int Health
        {
            get { return health; }
            set { health = value; }
        }

        public void TakeDamage()
        {
            int damage = (((((2 * power) / 5) + 2) * (attack / defense)) / 50) + 2;
            if (Health - damage <= 0)
            {
                Health = 0;
            }
            else
            {
                Health -= damage;
            }
        }

        public bool IsDead()
        {
            if (Health <= 0)
            {
                return true;
            }
            return false;
        }

        public override string ToString()
        {
            return "Name: " + name + " Health: " + health + " Attack: " + attack + " Defense: " + " Power: " + power;
        }
    }
}
