﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Combat
{
    class CombatPlayer
    {
        public int health;
        public int attack;
        public int defense;
        public int level;
        public int experience;

        public CombatPlayer(int hp, int atk, int def, int lvl, int exp)
        {
            health = hp;
            attack = atk;
            defense = def;
            level = lvl;
            experience = exp;
        }

        public int Health
        {
            get { return health; }
            set { health = value; }
        }

        public int Attack
        {
            get { return attack; }
            set { attack = value; }
        }

        public int Defense
        {
            get { return defense; }
            set { defense = value; }
        }

        public int Level
        {
            get { return level; }
            set { level = value; }
        }
        public int Experience
        {
            get { return experience; }
            set { experience = value; }
        }

        public void TakeDamage()
        {
            int damage = (((((2 * level) / 5) + 2) * (attack / defense)) / 50) + 2;
            if (Health - damage <= 0)
            {
                Health = 0;
            }
            else
            {
                Health -= damage;
            }
        }

        public bool IsDead()
        {
            if (Health <= 0)
            {
                return true;
            }
            return false;
        }

        public override string ToString()
        {
            return "Health: " + health + " Attack: " + attack + " Defense: " + " Level: " + level + " Exp: " + experience;
        }
    }
}
