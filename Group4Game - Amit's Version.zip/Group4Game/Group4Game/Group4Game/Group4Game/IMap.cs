﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group4Game
{
    public interface IMap
    {
        
        int Width { get; }
        int Height { get; }

        void Initialize( int width, int height);
        bool IsWalkable(int x, int y);
        void SetCellProperties(int x, int y, bool isWalkable);

        IEnumerable<ICell> GetAllCells();
        ICell GetCell(int x, int y);
        ICell CellFor(int index);

    }

    public class MapState
    {
        [Flags]
        public enum CellProperties
        {
            None = 0,
            Walkable = 1,
            Transparent = 2,
            Visible = 4,
            Explored = 8
        }

        public int Width { get; set; }
        public int Height { get; set; }
        public CellProperties[] Cells { get; set; }
    }
}
