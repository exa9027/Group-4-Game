﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Group4Game
{
    /// <summary>
    /// A class for performing field-of-view calculations to determine what is observable in a Map from a given Cell within a given light radius
    /// </summary>
    /// <seealso href="https://sites.google.com/site/jicenospam/visibilitydetermination">Based on the visibility determination algorithm described here</seealso>
    public class FieldOfView
    {
        private readonly IMap _map;
        private readonly HashSet<int> _inFov;

        /// <summary>
        /// Constructs a new FieldOfView class for the specified Map
        /// </summary>
        /// <param name="map">The Map that this FieldOfView class will use to perform its field-of-view calculations</param>
        public FieldOfView(IMap map)
        {
            _map = map;
            _inFov = new HashSet<int>();
        }

        internal FieldOfView(IMap map, HashSet<int> inFov)
        {
            _map = map;
            _inFov = inFov;
        }



        private enum Quadrant
        {
            NE = 1,
            SE = 2,
            SW = 3,
            NW = 4
        }
    }
}