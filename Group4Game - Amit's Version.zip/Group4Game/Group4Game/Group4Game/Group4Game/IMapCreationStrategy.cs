﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group4Game
{
    public interface IMapCreationStrategy<T> where T : IMap
    {
        /// <summary>
        /// Creates a new IMap of the specified type
        /// </summary>
        /// <returns>An IMap of the specified type</returns>
        T CreateMap();
    }
}