﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group4Game
{
    public static class Singleton
    {
        /// <summary>
        /// The DefaultRandom generator is DotNetRandom from System.Random
        /// </summary>
        /// CA2104 is thrown incorrectly on this line. Singleton.DefaultRandom is immutable.
        public static readonly DotNetRandom DefaultRandom = new DotNetRandom();
    }
}