﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group4Game
{
    public class Map : IMap
    {
        private bool[,] _isWalkable;

        /// <summary>
        /// Constructor creates a new uninitialized Map
        /// </summary>
        public Map()
        {
        }

        /// <summary>
        /// Constructor creates a new Map and immediately initializes it
        /// </summary>
        public Map(int width, int height)
        {
            Initialize(width, height);
        }

        /// <summary>
        /// tall and wide cells
        /// </summary>
        public int Width { get; private set; }
        public int Height { get; private set; }

        /// <summary>
        /// Create a new map with the properties of all Cells set to false
        /// </summary>
        public void Initialize(int width, int height)
        {
            Width = width;
            Height = height;
            _isWalkable = new bool[width, height];
        }

        /// <summary>
        /// Get the walkability of the Cell i.e. if a character could normally move across the Cell without difficulty
        /// </summary>
        public bool IsWalkable(int x, int y)
        {
            return _isWalkable[x, y];
        }


        /// <summary>
        /// Set the properties of a Cell to the specified values
        /// </summary>
        public void SetCellProperties(int x, int y, bool isWalkable)
        {
            _isWalkable[x, y] = isWalkable;
        }

        /// <summary>
        /// Set the properties of an unexplored Cell to the specified values
        /// </summary>
        public void SetCellProperties(int x, int y, bool isTransparent, bool isWalkable)
        {
            SetCellProperties(x, y, isWalkable);
        }

        /// <summary>
        /// Get an IEnumerable of all Cells in the Map
        /// </summary>
        public IEnumerable<ICell> GetAllCells()
        {
            for (int y = 0; y < Height; y++)
            {
                for (int x = 0; x < Width; x++)
                {
                    yield return GetCell(x, y);
                }
            }
        }

        /// <summary>
        /// Get a Cell at the specified location
        /// </summary>
        public ICell GetCell(int x, int y)
        {
            return new Cell(x, y, _isWalkable[x, y]);
        }

        /// <summary>
        /// Static factory method which creates a new Map using the specified IMapCreationStrategy
        /// </summary>
        public static Map Create(IMapCreationStrategy<Map> mapCreationStrategy)
        {
            if (mapCreationStrategy == null)
            {
                throw new ArgumentNullException("mapCreationStrategy", "Map creation strategy cannot be null");
            }

            return mapCreationStrategy.CreateMap();
        }

        /// Get the Cell at the specified single dimensional array index using the formulas: x = index % Width; y = index / Width;
        public ICell CellFor(int index)
        {
            int x = index % Width;
            int y = index / Width;

            return GetCell(x, y);
        }

        /// Get the single dimensional array index for a Cell at the specified location using the formula: index = ( y * Width ) + x
        public int IndexFor(int x, int y)
        {
            return (y * Width) + x;
        }

        /// Get the single dimensional array index for the specified Cell
        public int IndexFor(ICell cell)
        {
            if (cell == null)
            {
                throw new ArgumentNullException("cell", "Cell cannot be null");
            }

            return (cell.Y * Width) + cell.X;
        }

        private bool AddToHashSet(HashSet<int> hashSet, int x, int y, out ICell cell)
        {
            cell = GetCell(x, y);
            return hashSet.Add(IndexFor(cell));
        }
    }
}