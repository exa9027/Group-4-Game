﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group4Game
{
    public struct Point : IEquatable<Point>
    {
        private static readonly Point _zeroPoint = new Point();
        public int X { get; set; }
        public int Y { get; set; }

        #region Constructors

        public Point(int x, int y)
           : this()
        {
            X = x;
            Y = y;
        }

        public Point(int value)
           : this()
        {
            X = value;
            Y = value;
        }

        #endregion

        public static Point Zero
        {
            get { return _zeroPoint; }
        }

        #region Public methods

        /// <summary>
        ///   Compares whether current instance is equal to specified <see cref="Object" />.
        /// </summary>
        public override bool Equals(object obj)
        {
            return obj is Point && Equals((Point)obj);
        }

        /// <summary>
        ///   Compares whether current instance is equal to specified <see cref="Point" />.
        /// </summary>
        public bool Equals(Point other)
        {
            return (X == other.X) && (Y == other.Y);
        }

        /// <summary>
        ///   Gets the hash code of this <see cref="Point" />.
        /// </summary>
        public override int GetHashCode()
        {
            return X ^ Y;
        }
      #endregion
    }
}