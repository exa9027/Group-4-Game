﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group4Game
{
    public interface ICell : IEquatable<ICell>
    {
        /// <summary>
        /// Gets the X location of the Cell starting with 0 as the farthest left
        /// </summary>
        int X { get; }

        /// <summary>
        /// Y location of the Cell starting with 0 as the top
        /// </summary>
        int Y { get; }


        /// <summary>
        /// Get the walkability of the Cell i.e. if a character could normally move across the Cell without difficulty
        /// </summary>
        bool IsWalkable { get; }
    }
}