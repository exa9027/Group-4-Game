﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group4Game
{
    public class Cell : ICell
    {

        public Cell(int x, int y, bool isWalkable)
        {
            X = x;
            Y = y;

            IsWalkable = isWalkable;

        }

        public int X { get; private set; }
        public int Y { get; private set; }


        /// <summary>
        /// Get the walkability of the Cell i.e. if a character could normally move across the Cell without difficulty
        /// </summary>
        public bool IsWalkable { get; private set; }


        /// <summary>
        /// Determines whether two Cell instances are equal
        /// </summary>
        public bool Equals(ICell other)
        {
            if (ReferenceEquals(null, other))
            {
                return false;
            }
            if (ReferenceEquals(this, other))
            {
                return true;
            }
            return X == other.X && Y == other.Y && IsWalkable == other.IsWalkable;
        }

        /// <summary>
        /// Determines whether two Cell instances are equal
        /// </summary>
        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj))
            {
                return false;
            }
            if (ReferenceEquals(this, obj))
            {
                return true;
            }
            if (obj.GetType() != this.GetType())
            {
                return false;
            }
            return Equals((Cell)obj);
        }

        /// <summary>
        /// Determines whether two Cell instances are equal
        /// </summary>
        public static bool operator ==(Cell left, Cell right)
        {
            return Equals(left, right);
        }

        /// <summary>
        /// Determines whether two Cell instances are not equal
        /// </summary>
        public static bool operator !=(Cell left, Cell right)
        {
            return !Equals(left, right);
        }

        /// <summary>
        /// Gets the hash code for this object which can help for quick checks of equality
        /// or when inserting this Cell into a hash-based collection such as a Dictionary or Hashtable 
        /// </summary>
        /// <returns>An integer hash used to identify this Cell</returns>
        public override int GetHashCode()
        {
            unchecked
            {
                var hashCode = X;
                hashCode = (hashCode * 397) ^ Y;
                hashCode = (hashCode * 397) ^ IsWalkable.GetHashCode();
                return hashCode;
            }
        }
    }
}