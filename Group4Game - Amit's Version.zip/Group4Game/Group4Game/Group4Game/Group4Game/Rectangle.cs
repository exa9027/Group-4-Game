﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group4Game
{
    public struct Rectangle : IEquatable<Rectangle>
    {
        private static readonly Rectangle _emptyRectangle = new Rectangle();
        public int Height { get; set; }
        public int Width { get; set; }
        public int X { get; set; }
        public int Y { get; set; }

        /// <summary>
        /// Creates a new instance of <see cref="Rectangle"/> struct, with the specified
        /// </summary>
        public Rectangle(int x, int y, int width, int height)
        {
            this.X = x;
            this.Y = y;
            this.Width = width;
            this.Height = height;
        }

        public Rectangle(Point location, Point size)
        {
            this.X = location.X;
            this.Y = location.Y;
            this.Width = size.X;
            this.Height = size.Y;
        }

        public static Rectangle Empty
        {
            get
            {
                return _emptyRectangle;
            }
        }

        public int Left
        {
            get
            {
                return X;
            }
        }
        /// Returns the x-coordinate of the right side of the rectangle
        public int Right
        {
            get
            {
                return (X + Width);
            }
        }

        /// Returns the y-coordinate of the top of the rectangle
        public int Top
        {
            get
            {
                return Y;
            }
        }

        /// Returns the y-coordinate of the bottom of the rectangle
        public int Bottom
        {
            get
            {
                return (Y + Height);
            }
        }

        /// Gets or sets the Point representing the upper-left value of the Rectangle
        public Point Location
        {
            get
            {
                return new Point(X, Y);
            }
            set
            {
                X = value.X;
                Y = value.Y;
            }
        }

        /// Returns the Point that specifies the center of the rectangle
        public Point Center
        {
            get
            {
                return new Point(X + (Width / 2), Y + (Height / 2));
            }
        }

        /// Returns a value that indicates whether the Rectangle is empty
        public bool IsEmpty
        {
            get
            {
                return ((((Width == 0) && (Height == 0)) && (X == 0)) && (Y == 0));
            }
        }


        /// Determines whether two Rectangle instances are equal
        public bool Equals(Rectangle other)
        {
            return this == other;
        }

        /// <summary>
        /// Compares two rectangles for equality
        /// </summary>
        public static bool operator ==(Rectangle a, Rectangle b)
        {
            return ((a.X == b.X) && (a.Y == b.Y) && (a.Width == b.Width) && (a.Height == b.Height));
        }


        /// <summary>
        /// Compares two rectangles for inequality
        /// </summary>
        public static bool operator !=(Rectangle a, Rectangle b)
        {
            return !(a == b);
        }

        public override bool Equals(object obj)
        {
            return (obj is Rectangle) && this == ((Rectangle)obj);
        }

        /// <summary>
        /// Returns a string that represents the current Rectangle
        /// </summary>
        /// <returns>A string that represents the current Rectangle</returns>
        public override string ToString()
        {
            return string.Format("{{X:{0} Y:{1} Width:{2} Height:{3}}}", X, Y, Width, Height);
        }

        /// <summary>
        /// Gets the hash code for this object which can help for quick checks of equality
        /// or when inserting this Rectangle into a hash-based collection such as a Dictionary or Hashtable 
        /// </summary>
        /// <returns>An integer hash used to identify this Rectangle</returns>
        public override int GetHashCode()
        {
            return (X ^ Y ^ Width ^ Height);
        }

        /// <summary>
        /// Determines whether this Rectangle intersects with the specified Rectangle
        /// </summary>
        public bool Intersects(Rectangle value)
        {
            return value.Left < Right &&
                   Left < value.Right &&
                   value.Top < Bottom &&
                   Top < value.Bottom;
        }

        /// <summary>
        /// Determines whether this Rectangle intersects with the specified Rectangle
        /// </summary>
        public void Intersects(ref Rectangle value, out bool result)
        {
            result = value.Left < Right &&
                     Left < value.Right &&
                     value.Top < Bottom &&
                     Top < value.Bottom;
        }

        /// <summary>
        /// Creates a Rectangle defining the area where one Rectangle overlaps with another Rectangle
        /// </summary>
        public static Rectangle Intersect(Rectangle value1, Rectangle value2)
        {
            Rectangle rectangle;
            Intersect(ref value1, ref value2, out rectangle);
            return rectangle;
        }

        /// <summary>
        /// Creates a Rectangle defining the area where one Rectangle overlaps with another Rectangle
        /// </summary>
        public static void Intersect(ref Rectangle value1, ref Rectangle value2, out Rectangle result)
        {
            if (value1.Intersects(value2))
            {
                int rightSide = Math.Min(value1.X + value1.Width, value2.X + value2.Width);
                int leftSide = Math.Max(value1.X, value2.X);
                int topSide = Math.Max(value1.Y, value2.Y);
                int bottomSide = Math.Min(value1.Y + value1.Height, value2.Y + value2.Height);
                result = new Rectangle(leftSide, topSide, rightSide - leftSide, bottomSide - topSide);
            }
            else
            {
                result = new Rectangle(0, 0, 0, 0);
            }
        }

        /// <summary>
        /// Creates a new Rectangle that exactly contains the specified two Rectangles
        /// </summary>
        public static Rectangle Union(Rectangle value1, Rectangle value2)
        {
            int x = Math.Min(value1.X, value2.X);
            int y = Math.Min(value1.Y, value2.Y);
            return new Rectangle(x, y, Math.Max(value1.Right, value2.Right) - x, Math.Max(value1.Bottom, value2.Bottom) - y);
        }

        /// <summary>
        /// Creates a new <see cref="Rectangle"/> that completely contains two other rectangles.
        /// </summary>
        public static void Union(ref Rectangle value1, ref Rectangle value2, out Rectangle result)
        {
            result = Union(value1, value2);
        }
    }
}