﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group4Game
{
    public interface IRandom
    {
        /// <summary>
        /// Gets the next pseudo-random integer between 0 and the specified maxValue inclusive
        /// </summary>
        int Next(int maxValue);

        /// <summary>
        /// Gets the next pseudo-random integer between the specified minValue and maxValue inclusive
        /// </summary>
        int Next(int minValue, int maxValue);

    }
    /// <summary>
    /// A class representing the state of a pseudo-random number generation algorithm 
    /// </summary>
    public class RandomState
    {
        /// <summary>
        /// The seed that was originally used to create the pseudo-random number generator
        /// </summary>
        public int[] Seed { get; set; }

        public long NumberGenerated { get; set; }
    }
}