﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalTool
{
    class FileReader
    {
        private string file = "info.txt";

        public void Save(string name, int health, int attack, int defense)
        {
            StreamWriter output = null;

            try
            {
                output = new StreamWriter(file);
                output.WriteLine(name);
                output.WriteLine(health);
                output.WriteLine(attack);
                output.WriteLine(defense);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error Writing to the file: " + e.Message);
            }
            finally
            {
                output.Close();
            }
        }
    }
}
