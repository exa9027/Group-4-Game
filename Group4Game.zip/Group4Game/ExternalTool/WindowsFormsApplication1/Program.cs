﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExternalTool
{
    static class Program
    {
        /// <summary>
        /// Form program for external tool.
        /// Saves player info to a file that is loaded into the game.
        /// Worked on by: Ethan Adler, Gabriel Lanna, and Amit Nemani
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
