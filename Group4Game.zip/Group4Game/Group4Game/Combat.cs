﻿//Combat class for "Steve's Quest"

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group4Game
{
    class Combat
    {
        //Create random object
        Random rgen = new Random();

        //Sets up classes for combat enemy and combat player
        public CombatEnemy Enemy;
        public CombatPlayer Player;

        //Sets up the enemy to have the desired stats.
        public void GenerateEnemy(string name, int health, int attack, int defense, int power)
        {
            Enemy = new CombatEnemy(name, health, attack, defense, power);
        }

        //Sets up the player to have the desired stats.
        public void GeneratePlayer(int health, int attack, int defense, int level, int experience)
        {
            Player = new CombatPlayer(health, attack, defense, level, experience);
        }

        //Check if either player or enemy is dead.
        public bool AnyoneDead()
        {
            //Checks the "IsDead" methods from both enemy and player objects
            return (Player.IsDead() || Enemy.IsDead());
        }

        //Player attacking method
        public void PlayerAttack()
        {
            //make sure both are still alive
            if (!AnyoneDead())
            {
                //enemy health is reduced by the "EnemyTakeDamage" method
                Enemy.Health -= EnemyTakeDamage();

                //Check if the enemy has died from the attack
                if (Enemy.IsDead() == true)
                {
                    //If so, call the "GetXp" method to add experience to the player class.
                    Player.Experience += GetXp();
                    return;
                }
            }
        }

        //Enemy attacking method
        public void EnemyAttack()
        {
            //player health is reduced by the "PlayerTakeDamage" method
            Player.health -= PlayerTakeDamage();
        }

        //Calculation for the health that will be lost by the player.
        public int PlayerTakeDamage()
        {
            //Enemy power level x Enemy attack / Player Defense + a random number from 1 to the enemy power level. 
            return (Enemy.power * Enemy.attack) / Player.defense + rgen.Next(1, Enemy.power);
        }

        //Calculation for the health that will be lost by the enemy.
        public int EnemyTakeDamage()
        {
            //Player level x Player attack / Enemy Defense + a random number from 1 to the player level.
            return (Player.level * Player.attack) / Enemy.defense + rgen.Next(1, Player.level);
        }

        //Method that returns the health of both player and enemy, as well as the current experience of the enemy. To be used in the combat interface.
        public string GetStats()
        {
            return ("Enemy HP: " + Enemy.Health + "\nPlayer HP: " + Player.Health + "  Player Exp: " + Player.Experience);
        }

        //Calculates the experience to be given to the player after beating an enemy.
        public int GetXp()
        {
            //(10 / Enemy power level) x (Enemy power level ^ 3)
            return (10 / Enemy.power) * (int)(Math.Pow(Enemy.power, 3));
        }
    }
}
