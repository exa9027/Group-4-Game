﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;

namespace Group4Game
{
    /// <summary>
    /// Main Game File for Group 4's Game
    /// Enemy is red, Player is blackish-blue, walls are green
    /// Worked on by Ethan Adler, Amit Nemani, Gabriel Lanna and Dillon Chan.
    /// </summary>
    public class Game1 : Game
    {

        //Sets up graphical objects
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        SpriteFont font;
        Texture2D playerSheet;
        Texture2D combatPlayerSheet;
        Texture2D enemySheet;
        Texture2D wallSheet;
        Texture2D background;
        Texture2D stairPic;
        Texture2D gameOverPic;
        Texture2D winPic;
        Texture2D plusSign;
        Texture2D minusSign;
        // Texture2D endPic;

        //ariable to check if player is currently colliding with the stairs
        bool onStairs = true;

        //Reads the text file set up by the External Tool
        StreamReader output = new StreamReader("..\\..\\..\\..\\..\\ExternalTool\\WindowsFormsApplication1\\bin\\Debug\\info.txt");

        //Timer for the game
        int timer;

        //Currently unused enum for game states
        enum GameState { Map, Battle }


        //Sets up the floor and room the player will be on.
        int level;
        int room;
        MapInterface MapInter;

        //Object for the enemy engaged in combat
        MapEnemy enemyInCombat;

        //List of all walls currently on screen.
        List<Rectangle> currentWalls;

        //Sets up the main state machine
        //GameState state;
        FSM stateMachine;

        //Textures and mouse object for the main menu
        Texture2D startButton;
        Texture2D MenuButton;
        Texture2D MenuButtonPressed;
        Texture2D MenuButtonHover;
        Texture2D Cursor;
        Texture2D Title;
        //Texture2D CursorHover;
        MouseState mouse;

        //Random object
        Random rgen;


        //Combat object and enum to check whose turn it currently is.
        Combat obj = new Combat();
        enum Turn { player, enemy };
        Turn currentTurn;

        //Graphical objects for combat.
        Texture2D playerStatus;
        Texture2D enemyStatus;
        Texture2D hp;
        Texture2D xp;
        CombatInterface ComInter;

        //Sets up the Boss rectangle
        Rectangle bossRec = new Rectangle(1000, 400, 200, 200);

        //Keyboard object
        KeyboardState current;

        //Sets up how many points the player initially has to spend on skills.
        int points = 27;

        //Set ints for leveling up
        int hAdd = 0;
        int aAdd = 0;
        int dAdd = 0;

        //Creates the player object and rectangle
        Player player;
        Rectangle playerRec = new Rectangle(60, 60, 50, 50);
        int moveSpeed = 15;

        //Creates and set's up list of list of enemies, for all the different groups of enemies in the different rooms
        List<List<MapEnemy>> roomEnemies = new List<List<MapEnemy>>();
        MapEnemy mapEnemy1 = new MapEnemy();
        List<MapEnemy> enemyList1 = new List<MapEnemy>();
        List<MapEnemy> enemyList2 = new List<MapEnemy>();
        List<MapEnemy> enemyList3 = new List<MapEnemy>();
        List<MapEnemy> currentEnemyList = new List<MapEnemy>();

        //Creates and set's up list of list of walls, for all the different groups of walls in the different rooms
        List<List<Rectangle>> wallRoomList = new List<List<Rectangle>>();
        List<Rectangle> wallList1 = new List<Rectangle>();
        List<Rectangle> wallList2 = new List<Rectangle>();
        List<Rectangle> wallList3 = new List<Rectangle>();
        List<Rectangle> wallList4 = new List<Rectangle>();

        //Rectangle for the stairs
        Rectangle stairs = new Rectangle(500, 500, 50, 50);

        //Rectangles for the level up screen.
        Rectangle recHealthPlus;
        Rectangle recHealthMinus;
        Rectangle recAtkPlus;
        Rectangle recAtkMinus;
        Rectangle recDefPlus;
        Rectangle recDefMinus;

        //initializes player main stats.
        string playerNm = "";
        int playerHp = 0;
        int playerAtk = 0;
        int playerDf = 0;

        List<Texture2D> sprites = new List<Texture2D>();
        Texture2D ratImage;
        Texture2D batImage;
        Texture2D snakeImage;
        Texture2D impImage;

        //Constructor for the Game1 class.
        public Game1()
        {
            //initializes random object.
            rgen = new Random();



            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            this.graphics.PreferredBackBufferWidth = 1500;
            this.graphics.PreferredBackBufferHeight = 900;
            this.IsMouseVisible = true;
            this.graphics.ApplyChanges();

            //Sets mapEnemy1 object's move enum to direct it to the left.
            mapEnemy1.Move = Movement.Left;

            //Read info from the text file set up by the External Tool
            bool atEnd = false;
            while (atEnd == false)
            {
                string line = output.ReadLine();
                playerNm = line;
                line = output.ReadLine();
                playerHp = int.Parse(line);
                line = output.ReadLine();
                playerAtk = int.Parse(line);
                line = output.ReadLine();
                playerDf = int.Parse(line);
                atEnd = true;
            }

            //Setds up the Player object to have the initial stats controlled by the External Tool
            player = new Player(playerNm, playerHp, playerAtk, playerDf, 0, 1);


            //Creates the three enemies to be in the first room, and adds them to the the first list of enemies.
            MapEnemy mapEnemy2 = new MapEnemy();
            mapEnemy2.EnemyRec = new Rectangle(400, 300, 50, 50);
            mapEnemy2.Move = Movement.Left;

            MapEnemy mapEnemy3 = new MapEnemy();
            mapEnemy3.EnemyRec = new Rectangle(400, 600, 50, 50);
            mapEnemy3.Move = Movement.Left;

            enemyList1.Add(mapEnemy1);
            enemyList1.Add(mapEnemy2);
            enemyList1.Add(mapEnemy3);


            //Creates the two enemies to be in the second room, and adds them to the the second list of enemies.
            MapEnemy mapEnemy4 = new MapEnemy();
            mapEnemy4.EnemyRec = new Rectangle(400, 300, 50, 50);
            mapEnemy4.Move = Movement.Left;

            MapEnemy mapEnemy5 = new MapEnemy();
            mapEnemy5.EnemyRec = new Rectangle(400, 750, 50, 50);
            mapEnemy5.Move = Movement.Left;

            enemyList2.Add(mapEnemy4);
            enemyList2.Add(mapEnemy5);


            //Creates the enemy to be in the third room, and adds it to the third list of enemies.
            MapEnemy mapEnemy6 = new MapEnemy();
            mapEnemy6.EnemyRec = new Rectangle(400, 300, 50, 50);
            mapEnemy6.Move = Movement.Left;

            enemyList3.Add(mapEnemy6);


            //Selects the initial room and level of the map
            level = 1;
            room = 1;


            //Adds the lists of walls to the list of list of walls
            wallRoomList.Add(wallList1);
            wallRoomList.Add(wallList2);
            wallRoomList.Add(wallList3);
            wallRoomList.Add(wallList4);

            //Adds the lists of enemies to the list of list of enemies
            roomEnemies.Add(enemyList1);
            roomEnemies.Add(enemyList2);
            roomEnemies.Add(enemyList3);


            //Sets the current lists to equal the first ones in the lists of lists
            currentEnemyList = roomEnemies[0];
            currentWalls = wallRoomList[0];
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            //Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            //Sets up the font
            font = Content.Load<SpriteFont>("SpriteFont1");

            //Sets up the player sprite
            playerSheet = Content.Load<Texture2D>("TransparentSteve2.png");
            combatPlayerSheet = Content.Load<Texture2D>("Steve.png");

            // set up enemy
            enemySheet = Content.Load<Texture2D>("Monster.png");

            //Sets up the wall sprite
            wallSheet = Content.Load<Texture2D>("genericWall.tif");
            background = Content.Load < Texture2D>("floorStitch3.tif");

            //Sets up the wall rectangles
            Rectangle wallRec11 = new Rectangle(0, 0, 50, 900);
            Rectangle wallRec12 = new Rectangle(0, 0, 1500, 50);
            Rectangle wallRec13 = new Rectangle(1450, 0, 50, 900);
            Rectangle wallRec3 = new Rectangle(0, 850, 1500, 50);


            //Adds the rectangles to the first list fo walls
            wallList1.Add(wallRec12);
            wallList1.Add(wallRec11);
            wallList1.Add(wallRec13);

            //Adds the rectangles to the second list fo walls
            wallList2.Add(wallRec3);
            wallList2.Add(wallRec11);

            //Adds the rectangles to the third list fo walls
            wallList3.Add(wallRec3);
            wallList3.Add(wallRec13);
            wallList3.Add(wallRec12);

            //Adds the rectangles to the fourth list fo walls
            wallList4.Add(wallRec3);
            wallList4.Add(wallRec13);
            wallList4.Add(wallRec12);
            wallList4.Add(wallRec11);


            //Loads the textures from the Content folder
            startButton = Content.Load<Texture2D>("rectangle.png");
            MenuButton = Content.Load<Texture2D>("MB.png");
            MenuButtonHover = Content.Load<Texture2D>("MBH.png");
            MenuButtonPressed = Content.Load<Texture2D>("MBP.png");
            Cursor = Content.Load<Texture2D>("Cursor.png");
            stairPic = Content.Load<Texture2D>("New Piskel.png");
            gameOverPic = Content.Load<Texture2D>("GameOver.png");
            winPic = Content.Load<Texture2D>("WinScreen.png");
            playerStatus = Content.Load<Texture2D>("PlayerStatus3.png");
            enemyStatus = Content.Load<Texture2D>("EnemyStatus3.png");
            hp = Content.Load<Texture2D>("HP.png");
            xp = Content.Load<Texture2D>("XPBar.png");
            Title = Content.Load<Texture2D>("Title.png");

            //Sets up the objects for the FSM, Combat Interface, and Map Interface classes
            stateMachine = new FSM(MenuButton, font, Title);
            ComInter = new CombatInterface(null, null, playerStatus, enemyStatus, hp, xp, font, GraphicsDevice.Viewport.Height, GraphicsDevice.Viewport.Width);
            MapInter = new MapInterface(playerStatus, hp, xp, font, GraphicsDevice.Viewport.Height, GraphicsDevice.Viewport.Width);

            //Creates new MapEnemy objects
            MapEnemy mapEnemy2 = new MapEnemy();
            MapEnemy mapEnemy3 = new MapEnemy();

            //First Room Area
            Rectangle room11 = new Rectangle(0, 850, 500, 50);
            Rectangle room12 = new Rectangle(1000, 850, 450, 50);
            Rectangle room13 = new Rectangle(0, 250, 950, 50);
            Rectangle room14 = new Rectangle(300, 450, 1050, 50);
            Rectangle room15 = new Rectangle(500, 650, 500, 50);
            Rectangle room16 = new Rectangle(1000, 650, 200, 200);

            //Second Room Area
            Rectangle room21 = new Rectangle(0, 0, 500, 50);
            Rectangle room22 = new Rectangle(1000, 0, 500, 50);
            Rectangle room23 = new Rectangle(600, 200, 500, 300);
            Rectangle room24 = new Rectangle(200, 400, 150, 500);
            Rectangle room25 = new Rectangle(1450, 0, 50, 500);
            Rectangle room26 = new Rectangle(1450, 700, 50, 500);

            //Third Room Area
            Rectangle room31 = new Rectangle(0, 0, 50, 500);
            Rectangle room32 = new Rectangle(0, 700, 50, 500);

            //First Room
            wallList1.Add(wallRec12);
            wallList1.Add(wallRec11);
            wallList1.Add(wallRec13);
            wallList1.Add(room11);
            wallList1.Add(room12);
            wallList1.Add(room13);
            wallList1.Add(room14);
            wallList1.Add(room15);
            wallList1.Add(room16);


            //Second Room
            wallList2.Add(wallRec3);
            wallList2.Add(wallRec11);
            wallList2.Add(room21);
            wallList2.Add(room22);
            wallList2.Add(room23);
            wallList2.Add(room24);
            wallList2.Add(room25);
            wallList2.Add(room26);

            //Third Room
            wallList3.Add(wallRec3);
            wallList3.Add(wallRec13);
            wallList3.Add(wallRec12);
            wallList3.Add(room31);
            wallList3.Add(room32);

            plusSign = Content.Load<Texture2D>("Plus.png");
            minusSign = Content.Load<Texture2D>("Minus.png");

            ratImage = Content.Load<Texture2D>("Rat.png");
            sprites.Add(ratImage);
            batImage = Content.Load<Texture2D>("Bat.png");
            sprites.Add(batImage);
            snakeImage = Content.Load<Texture2D>("Snake.png");
            sprites.Add(snakeImage);
            impImage = Content.Load<Texture2D>("Imp.png");
            sprites.Add(impImage);
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            //Sets up control keyboard and mouse readers for single click buttons.
            KeyboardState previous = current;
            MouseState previousMouse = mouse;

            //Reads the keyboard and mouse input
            KeyboardState kbInput = Keyboard.GetState();
            current = Keyboard.GetState();
            mouse = Mouse.GetState();

            //Run if the current state of the game is 'gameOver'
            if (stateMachine.state == FSM.gameState.gameOver)
            {
                if (kbInput.IsKeyDown(Keys.Enter) && previous != kbInput)
                {
                    stateMachine.state = FSM.gameState.mainMenu;
                }
            }
            //Run if the current state of the game is 'mainMenu'
            if (stateMachine.state == FSM.gameState.mainMenu)
            {
                //Sets state to equal level up if player clicks start
                if (stateMachine.StartButtonRect.Contains(mouse.Position))
                {
                    if (mouse.LeftButton == ButtonState.Pressed && previousMouse.LeftButton != mouse.LeftButton)
                    {
                        playerRec = new Rectangle(60, 60, 50, 50);
                        level = 1;
                        room = 1;
                        currentEnemyList = roomEnemies[0];
                        currentWalls = wallRoomList[0];
                        //Resets the enemies on screen
                        foreach (List<MapEnemy> list in roomEnemies)
                        {

                            for (int i = 0; i < list.Count; i++)
                            {
                                Rectangle rec = list[i].EnemyRec;
                                list[i] = new MapEnemy();
                                list[i].EnemyRec = rec;
                            }
                        }
                        player = new Player(playerNm, playerHp, playerAtk, playerDf, 0, 1);
                        points = 27;
                        stateMachine.state = FSM.gameState.levelUp;
                    }
                }

                //Sets state to equal quitting if player clicks start
                if (stateMachine.QuitButtonRect.Contains(mouse.Position))
                {
                    if (mouse.LeftButton == ButtonState.Pressed && previousMouse.LeftButton != mouse.LeftButton)
                    {
                        stateMachine.state = FSM.gameState.quitting;
                    }
                }
            }
            //Run if the current state of the game is 'game'
            if (stateMachine.state == FSM.gameState.game)
            {
                //Variable to control player collisions with the wall
                bool moved = false;

                //Move player up if pressing up
                if (kbInput.IsKeyDown(Keys.Up))
                {
                    foreach (Rectangle rec in currentWalls)
                    {
                        if (playerRec.Intersects(rec) == false && moved == false)
                        {
                            playerRec.Y -= moveSpeed;
                            moved = true;
                        }
                        if (playerRec.Intersects(rec))
                        {
                            playerRec.Y = playerRec.Y + moveSpeed;
                        }
                    }
                }

                //Move player down if pressing down
                if (kbInput.IsKeyDown(Keys.Down))
                {
                    foreach (Rectangle rec in currentWalls)
                    {
                        if (rec.Intersects(playerRec) == false && moved == false)
                        {
                            playerRec.Y += moveSpeed;
                            moved = true;
                        }
                        if (rec.Intersects(playerRec))
                        {
                            playerRec.Y = playerRec.Y - moveSpeed;
                        }
                    }
                }

                //Move player right if pressing right
                if (kbInput.IsKeyDown(Keys.Right))
                {
                    foreach (Rectangle rec in currentWalls)
                    {
                        if (rec.Intersects(playerRec) == false && moved == false)
                        {
                            playerRec.X += moveSpeed;
                            moved = true;
                        }
                        if (rec.Intersects(playerRec))
                        {
                            playerRec.X = playerRec.X - moveSpeed;
                        }
                    }
                }

                //Move player left if pressing left
                if (kbInput.IsKeyDown(Keys.Left))
                {
                    foreach (Rectangle rec in currentWalls)
                    {
                        if (rec.Intersects(playerRec) == false && moved == false)
                        {
                            playerRec.X -= moveSpeed;
                            moved = true;
                        }
                        if (rec.Intersects(playerRec))
                        {
                            playerRec.X = playerRec.X + moveSpeed;
                        }

                    }
                }

                // sets up the status bar in the map
                MapInter.PlayerTotalHp = player.MaxHealth;
                MapInter.PlayerCurrentHp = player.Health;
                MapInter.TotalXp = player.ToNextLevel;
                MapInter.CurrentXp = player.Experience;

                //Code to check if player is colliding with any of the living enemies
                foreach (MapEnemy enemy in currentEnemyList)
                {
                    if (playerRec.Intersects(enemy.EnemyRec) && enemy.Alive == true)
                    {
                        //Sets the game state to equal 'battle'
                        stateMachine.state = FSM.gameState.battle;


                        //Generates the CombatEnemy class from the MapEnemy class
                        string type = enemy.Chose(level);
                        int[] stats = enemy.Generate(type, sprites);
                        obj.GenerateEnemy(type, stats[0], stats[1], stats[2], stats[3]);

                        //Generates the CombatPlayer class from the Player class
                        obj.GeneratePlayer(player.Health, player.Attack, player.Defense, player.Level, player.Experience);


                        //Sets the player to begin the fight
                        currentTurn = Turn.player;

                        //Sets the combat interface
                        ComInter.PlayerSprite = combatPlayerSheet;
                        ComInter.EnemySprite = enemy.enemySprite;
                        ComInter.PlayerCurrentHp = player.Health;
                        ComInter.PlayerTotalHp = player.MaxHealth;
                        ComInter.EnemyCurrentHp = obj.Enemy.health;
                        ComInter.EnemyTotalHp = ComInter.EnemyCurrentHp;
                        ComInter.TotalXp = player.ToNextLevel;
                        ComInter.CurrentXp = player.Experience;
                        ComInter.EnemyName = obj.Enemy.name;



                        //Sets the enemy currently engaged in combat to equal the enemy collided with
                        enemyInCombat = enemy;
                    }
                }

                //Loop through all enemies on screen
                foreach (MapEnemy enemy in currentEnemyList)
                {
                    //Move the enemies left or right
                    if (enemy.Move == Movement.Left)
                    {
                        Rectangle rec = enemy.EnemyRec;
                        rec.X--;
                        enemy.EnemyRec = rec;
                    }
                    if (enemy.Move == Movement.Right)
                    {
                        Rectangle rec = enemy.EnemyRec;
                        rec.X++;
                        enemy.EnemyRec = rec;
                    }

                    //Check for collisions with the walls, and change the direction of the enemy if there is one.
                    foreach (Rectangle wall in currentWalls)
                    {
                        if (enemy.EnemyRec.Intersects(wall))
                        {
                            if (enemy.Move == Movement.Left)
                            {
                                enemy.Move = Movement.Right;
                                return;
                            }
                            if (enemy.Move == Movement.Right)
                            {
                                enemy.Move = Movement.Left;
                                return;
                            }
                        }
                    }
                }


                //Code to switch player from room 1 to room 2
                if (playerRec.Y > 880 && kbInput.IsKeyDown(Keys.Down))
                {
                    if (room == 1)
                    {
                        room = 2;
                        playerRec.Y = 0;
                        currentEnemyList = roomEnemies[1];
                        currentWalls = wallRoomList[1];
                    }
                }
                //Code to switch player from room 2 to room 1
                if (playerRec.Y < 0 && kbInput.IsKeyDown(Keys.Up))
                {
                    if (room == 2)
                    {
                        room = 1;
                        playerRec.Y = 900;
                        currentEnemyList = roomEnemies[0];
                        currentWalls = wallRoomList[0];
                    }
                }
                //Code to switch player from room 2 to room 3
                if (playerRec.X > 1500 && kbInput.IsKeyDown(Keys.Right))
                {
                    if (room == 2)
                    {
                        onStairs = true;
                        room = 3;
                        playerRec.X = 0;
                        currentEnemyList = roomEnemies[2];
                        currentWalls = wallRoomList[2];
                    }
                }
                //Code to switch player from room 3 to room 2
                if (playerRec.X < 0 && kbInput.IsKeyDown(Keys.Left))
                {
                    if (room == 3)
                    {
                        room = 2;
                        playerRec.X = 1500;
                        currentEnemyList = roomEnemies[1];
                        currentWalls = wallRoomList[1];
                    }
                }


                //CHecks if player collided with stairs
                if (playerRec.Intersects(stairs) && onStairs == true && room == 3)
                {
                    //Recovers the player's health
                    player.Health = player.MaxHealth;

                    //Reset player location on screen
                    playerRec.X = 60;
                    playerRec.Y = 60;

                    //Adds to the dungeon level variable
                    level++;

                    //If the player is in the 6th level, set the state to equal 'boss' and change the wall list accordingly
                    if (level >= 6)
                    {
                        stateMachine.state = FSM.gameState.boss;
                        currentWalls = wallRoomList[3];
                        return;
                    }

                    //Reset the room variable to equal the first room, changing the lists of walls and enemies accordingly
                    room = 1;
                    currentEnemyList = roomEnemies[0];
                    currentWalls = wallRoomList[0];

                    //Resets the enemies on screen
                    foreach (List<MapEnemy> list in roomEnemies)
                    {

                        for (int i = 0; i < list.Count; i++)
                        {
                            Rectangle rec = list[i].EnemyRec;
                            list[i] = new MapEnemy();
                            list[i].EnemyRec = rec;
                        }
                    }

                    //make the player no longer be on the stairs
                    onStairs = false;
                }

            }
            //Run if the current state of the game is 'battle'
            if (stateMachine.state == FSM.gameState.battle)
            {
                //chack if both parties in combat are alive
                if (!obj.AnyoneDead())
                {
                    //Checks if it is currently the player's turn
                    if (currentTurn == Turn.player && timer <= 0)
                    {
                        //Controls the player attacking
                        if (current.IsKeyDown(Keys.Enter) && current != previous)
                        {
                            obj.PlayerAttack();
                            currentTurn = Turn.enemy;
                            ComInter.EnemyCurrentHp = obj.Enemy.Health;
                        }
                    }
                    else
                    {
                        //Controls the enemy attacking
                        obj.EnemyAttack();
                        timer = 10;
                        while (timer >= 0)
                        {
                            System.Threading.Thread.Sleep(200);
                            timer--;
                        }
                        currentTurn = Turn.player;
                        ComInter.PlayerCurrentHp = obj.Player.Health;
                    }
                }
                else
                {
                    //Checks if it is the enemy who died
                    if (obj.Enemy.Health <= 0)
                    {
                        //sets up the earned expereince
                        ComInter.TotalXp = ComInter.TotalXp + obj.GetXp();

                        //kills the MapEnemy that was enegaged in combat
                        foreach (MapEnemy enemy in currentEnemyList)
                        {
                            if (enemy == enemyInCombat)
                            {
                                enemy.Alive = false;
                            }
                        }

                        //Gives the player expereince
                        player.Experience = obj.Player.Experience;

                        //Resets the player's health to equal it at the end of combat
                        player.Health = obj.Player.Health;


                        //checks if the player has leveled up
                        if (player.LevelUp())
                        {
                            //if so, give him 14 points to spend and change the state to 'levelUp'
                            points = 14;
                            stateMachine.state = FSM.gameState.levelUp;
                        }
                        //if not, go back to game
                        else { stateMachine.state = FSM.gameState.game; }


                        //if the defeated enemy was the boss, end the game.
                        if (obj.Enemy.name == "Boss")
                        {
                            stateMachine.state = FSM.gameState.gameOver;
                        }
                    }

                    //If it is the player who has died
                    if (obj.Player.Health <= 0)
                    {
                        //Resets the player's health to equal it at the end of combat
                        player.Health = obj.Player.Health;

                        //end the game
                        stateMachine.state = FSM.gameState.gameOver;
                    }

                }

            }
            //Run if the current state of the game is 'boss'
            if (stateMachine.state == FSM.gameState.boss)
            {
                //Variable to control player collisions with the wall
                bool moved = false;

                //Move player up if pressing up
                if (kbInput.IsKeyDown(Keys.Up))
                {
                    foreach (Rectangle rec in currentWalls)
                    {
                        if (playerRec.Intersects(rec) == false && moved == false)
                        {
                            playerRec.Y -= moveSpeed;
                            moved = true;
                        }
                        if (playerRec.Intersects(rec))
                        {
                            playerRec.Y = playerRec.Y + moveSpeed;
                        }
                    }
                }

                //Move player down if pressing down
                if (kbInput.IsKeyDown(Keys.Down))
                {
                    foreach (Rectangle rec in currentWalls)
                    {
                        if (rec.Intersects(playerRec) == false && moved == false)
                        {
                            playerRec.Y += moveSpeed;
                            moved = true;
                        }
                        if (rec.Intersects(playerRec))
                        {
                            playerRec.Y = playerRec.Y - moveSpeed;
                        }
                    }
                }

                //Move player right if pressing right
                if (kbInput.IsKeyDown(Keys.Right))
                {
                    foreach (Rectangle rec in currentWalls)
                    {
                        if (rec.Intersects(playerRec) == false && moved == false)
                        {
                            playerRec.X += moveSpeed;
                            moved = true;
                        }
                        if (rec.Intersects(playerRec))
                        {
                            playerRec.X = playerRec.X - moveSpeed;
                        }
                    }
                }

                //Move player left if pressing left
                if (kbInput.IsKeyDown(Keys.Left))
                {
                    foreach (Rectangle rec in currentWalls)
                    {
                        if (rec.Intersects(playerRec) == false && moved == false)
                        {
                            playerRec.X -= moveSpeed;
                            moved = true;
                        }
                        if (rec.Intersects(playerRec))
                        {
                            playerRec.X = playerRec.X + moveSpeed;
                        }

                    }
                }

                //Checks if the player has collided with the boss
                if (playerRec.Intersects(bossRec))
                {
                    //send the player to a battle state.
                    stateMachine.state = FSM.gameState.battle;

                    //Sets up the CombatEnemy object to have the Bosses stats
                    obj.GenerateEnemy("Boss", 50, 50, 50, 8);

                    //Generates the CombatPlayer class from the Player class
                    obj.GeneratePlayer(player.Health, player.Attack, player.Defense, player.Level, player.Experience);

                    //Sets the player to begin the fight
                    currentTurn = Turn.player;

                    //Sets the combat interface
                    ComInter.PlayerSprite = combatPlayerSheet;
                    ComInter.PlayerCurrentHp = player.Health;
                    ComInter.PlayerTotalHp = player.MaxHealth;
                    ComInter.EnemyCurrentHp = obj.Enemy.health;
                    ComInter.EnemyTotalHp = ComInter.EnemyCurrentHp;
                    ComInter.TotalXp = player.ToNextLevel;
                    ComInter.CurrentXp = player.Experience;
                    ComInter.EnemyName = obj.Enemy.name;

                    MapInter.PlayerTotalHp = player.MaxHealth;
                    MapInter.PlayerCurrentHp = player.Health;
                    MapInter.TotalXp = player.ToNextLevel;
                    MapInter.CurrentXp = player.Experience;
                }
            }
            //Run if the current state of the game is 'levelUp'
            if (stateMachine.state == FSM.gameState.levelUp)
            {
                //Sets up interface for the level up screen
                recHealthPlus = new Rectangle(200, 198, 25, 25);
                recHealthMinus = new Rectangle(200, 227, 25, 25);
                recAtkPlus = new Rectangle(200, 398, 25, 25);
                recAtkMinus = new Rectangle(200, 427, 25, 25);
                recDefPlus = new Rectangle(200, 598, 25, 25);
                recDefMinus = new Rectangle(200, 627, 25, 25);

                //Check if the mouse is on the mouse button
                if (recHealthPlus.Contains(mouse.Position) && player.MaxHealth < 100)
                {
                    if (mouse.LeftButton == ButtonState.Pressed && previousMouse.LeftButton != mouse.LeftButton)
                    {
                        if (points != 0)
                        {
                            hAdd++;
                            points--;
                        }
                    }
                }
                if (recHealthMinus.Contains(mouse.Position) && player.MaxHealth < 100)
                {
                    if (mouse.LeftButton == ButtonState.Pressed && previousMouse.LeftButton != mouse.LeftButton)
                    {
                        if (hAdd != 0)
                        {
                            hAdd--;
                            points++;
                        }
                    }
                }

                if (recAtkPlus.Contains(mouse.Position) && player.MaxHealth < 100)
                {
                    if (mouse.LeftButton == ButtonState.Pressed && previousMouse.LeftButton != mouse.LeftButton)
                    {
                        if (points != 0)
                        {
                            aAdd++;
                            points--;
                        }
                    }
                }
                if (recAtkMinus.Contains(mouse.Position) && player.MaxHealth < 100)
                {
                    if (mouse.LeftButton == ButtonState.Pressed && previousMouse.LeftButton != mouse.LeftButton)
                    {
                        if (aAdd != 0)
                        {
                            aAdd--;
                            points++;
                        }
                    }
                }

                if (recDefPlus.Contains(mouse.Position) && player.MaxHealth < 100)
                {
                    if (mouse.LeftButton == ButtonState.Pressed && previousMouse.LeftButton != mouse.LeftButton)
                    {
                        if (points != 0)
                        {
                            dAdd++;
                            points--;
                        }
                    }
                }
                if (recDefMinus.Contains(mouse.Position) && player.MaxHealth < 100)
                {
                    if (mouse.LeftButton == ButtonState.Pressed && previousMouse.LeftButton != mouse.LeftButton)
                    {
                        if (dAdd != 0)
                        {
                            dAdd--;
                            points++;
                        }
                    }
                }

                //if so, check if there is still space for leveling up
                if (points <= 0)
                {
                    //Top up player health, and go back to 'game' state
                    player.MaxHealth += hAdd;
                    hAdd = 0;
                    player.Attack += aAdd;
                    aAdd = 0;
                    player.Defense += dAdd;
                    dAdd = 0;
                    player.Health = player.MaxHealth;
                    stateMachine.state = FSM.gameState.game;
                }
            }
            //Run if the current state of the game is 'quitting'
            if (stateMachine.state == FSM.gameState.quitting)
            {
                //exit the game
                Exit();
            }

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            
            spriteBatch.Begin();
            spriteBatch.Draw(background, new Rectangle(0, 0, 1500, 900), Color.White);
            //Run if the current state is 'mainMenu'
            if (stateMachine.state == FSM.gameState.mainMenu)
            {
                //Draw the menu from the FSM class
                stateMachine.FSMDraw(spriteBatch);

                //Draw a mouse sprite
                spriteBatch.Draw(Cursor, new Rectangle(mouse.Position.X, mouse.Position.Y, 20, 20), Color.White);
            }
            //Run if the current state is 'game'
            if (stateMachine.state == FSM.gameState.game)
            {
                //Draw the player
                spriteBatch.Draw(playerSheet, playerRec, Color.White);

                //Draw the enemies
                foreach(MapEnemy enemy in currentEnemyList)
                {
                    if (enemy.Alive == true)
                    {
                        spriteBatch.Draw(enemySheet, enemy.EnemyRec, Color.Red);
                    }
                }
                
               
                //Draw the Walls
                foreach (Rectangle rec in currentWalls)
                {
                    spriteBatch.Draw(wallSheet, rec, Color.White);
                }
                //Display debug text
                Vector2 wordposit = new Vector2(200, 720);
                spriteBatch.DrawString(font, "Name: " + player.Name + " Health: " + player.Health + " Attack: " + player.Attack + 
                    " Defense: " + player.Defense + " Level: " + player.Level + " Exp: " + player.Experience + " To next Level: " + player.ExpToLevel(), wordposit, Color.White); 
                
                //Draw the staris if in room 3
                if (room == 3)       
                {
                    spriteBatch.Draw(stairPic, stairs, Color.White);
                }

                spriteBatch.Draw(combatPlayerSheet, new Rectangle(23, 805, 75, 75), Color.White);
                // Draws health on the map
                MapInter.draw(spriteBatch);

                //Draw debug text
                spriteBatch.DrawString(font, "Floor: " + level + " Room: " + room, new Vector2(10, 10), Color.White);
            }
            //Run if the current state is 'battle'
            if (stateMachine.state == FSM.gameState.battle)
            {
                //Draw debug text
                spriteBatch.DrawString(font, obj.GetStats(), new Vector2(0, 100), Color.White);

                //Use COmbatInterface class to draw the interface
                ComInter.draw(spriteBatch);
            }
            //Run if the current state is 'levleUp'
            if (stateMachine.state == FSM.gameState.levelUp)
            {
                //Draw the level up buttons and text
                spriteBatch.DrawString(font, "Points to spend: " + points, new Vector2(recHealthPlus.X, recHealthPlus.Y - 50), Color.White);
                spriteBatch.Draw(plusSign, recHealthPlus, Color.White);
                spriteBatch.Draw(minusSign, recHealthMinus, Color.White);
                spriteBatch.DrawString(font, "Max Health: " + (player.MaxHealth + hAdd), new Vector2(recHealthPlus.X + 100, recHealthPlus.Y + 25), Color.White);
                spriteBatch.DrawString(font, "+" + hAdd, new Vector2(recHealthPlus.X - 50, recHealthPlus.Y + 25), Color.Green);
                spriteBatch.Draw(plusSign, recAtkPlus, Color.White);
                spriteBatch.Draw(minusSign, recAtkMinus, Color.White);
                spriteBatch.DrawString(font, "Attack: " + (player.Attack + aAdd), new Vector2(recAtkPlus.X + 100, recAtkPlus.Y + 25), Color.White);
                spriteBatch.DrawString(font, "+" + aAdd, new Vector2(recAtkPlus.X - 50, recAtkPlus.Y + 25), Color.Green);
                spriteBatch.Draw(plusSign, recDefPlus, Color.White);
                spriteBatch.Draw(minusSign, recDefMinus, Color.White);
                spriteBatch.DrawString(font, "Defense: " + (player.Defense + dAdd), new Vector2(recDefPlus.X + 100, recDefPlus.Y + 25), Color.White);
                spriteBatch.DrawString(font, "+" + dAdd, new Vector2(recDefPlus.X - 50, recDefPlus.Y + 25), Color.Green);
            }
            //Run if the current state is 'boss'
            if (stateMachine.state == FSM.gameState.boss)
            {
                //Draw the player
                spriteBatch.Draw(playerSheet, playerRec, Color.White);

                //Draw the boss
                spriteBatch.Draw(playerSheet, bossRec, Color.Red);

                //Draw the walls
                foreach(Rectangle rec in currentWalls)
                {
                    spriteBatch.Draw(wallSheet, rec, Color.White);
                }
            }
            //Run if the current state is 'gameOver'
            if (stateMachine.state == FSM.gameState.gameOver)
            {
                //Draw win/lose message depenign on player health when entering this state.
                if(player.Health > 0)
                {
                    // spriteBatch.DrawString(font, "You win!", new Vector2(500), Color.White);
                    spriteBatch.Draw(winPic, new Rectangle(0, 0, 1500, 900), Color.White);
                }
                else
                {
                    // spriteBatch.DrawString(font, "You lose!", new Vector2(500), Color.White);
                    spriteBatch.Draw(gameOverPic, new Rectangle(0, 0, 1500, 900), Color.White);
                }
            }
            spriteBatch.End();
            base.Draw(gameTime);
        }
    }
}
