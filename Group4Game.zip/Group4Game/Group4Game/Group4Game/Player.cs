﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group4Game
{
    class Player
    {
        string name;
        public string Name
        {
            get { return name; }
        }
        int heatlh;
        public int Health
        {
            get { return heatlh; }
        }
        int attack;
        public int Attack
        {
            get { return attack; }
        }
        int defense;
        public int Defense
        {
            get { return defense; }
        }

        public Player(string nm, int hp, int atk, int def)
        {
            name = nm;
            heatlh = hp;
            attack = atk;
            defense = def;
        }
    }
}
