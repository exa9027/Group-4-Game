﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;

namespace Group4Game
{
    /// <summary>
    /// Main Game File for Group 4's Game
    /// Enemy is red, Player is blackish-blue, walls are green
    /// Worked on by Ethan Adler, Amit Nemani, and Gabriel Lanna.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        SpriteFont font;
        Texture2D mapSheet;
        Texture2D playerSheet;
        Texture2D wallSheet;
        Texture2D stairPic;
        bool onStairs = true;
        StreamReader output = new StreamReader("..\\..\\..\\..\\..\\ExternalTool\\WindowsFormsApplication1\\bin\\Debug\\info.txt");
        int timer;
        enum GameState { Map, Battle }
        // this is the floor you are onm
        int level;
        int room;
        MapEnemy enemyInCombat;
        List<Rectangle> currentWalls;
        GameState state;
        FSM stateMachine;
        Texture2D startButton;
        Texture2D MenuButton;
        Texture2D MenuButtonPressed;
        Texture2D MenuButtonHover;
        Texture2D Cursor;
        Texture2D CursorHover;
        MouseState mouse;
        Random rgen;
        // combat stuff
        Combat obj = new Combat();
        enum Turn { player, enemy };
        Turn currentTurn;

        Texture2D playerStatus;
        Texture2D enemyStatus;
        Texture2D hp;
        Texture2D xp;
        CombatInterface ComInter;

        Rectangle bossRec = new Rectangle(1000, 400, 200, 200);

        KeyboardState current;

        int points = 27;

        Player player;
        Rectangle playerRec = new Rectangle(60, 60, 50, 50);

        List<List<MapEnemy>> roomEnemies = new List<List<MapEnemy>>();
        MapEnemy mapEnemy1 = new MapEnemy();
        List<MapEnemy> enemyList1 = new List<MapEnemy>();
        List<MapEnemy> enemyList2 = new List<MapEnemy>();
        List<MapEnemy> enemyList3 = new List<MapEnemy>();
        List<MapEnemy> currentEnemyList = new List<MapEnemy>();

        List<List<Rectangle>> wallRoomList = new List<List<Rectangle>>();
        List<Rectangle> wallList1 = new List<Rectangle>();
        List<Rectangle> wallList2 = new List<Rectangle>();
        List<Rectangle> wallList3 = new List<Rectangle>();
        List<Rectangle> wallList4 = new List<Rectangle>();

        Rectangle stairs = new Rectangle(500, 500, 50, 50);

        Rectangle recHealth;
        Rectangle recAtk;
        Rectangle recDef;

        public Game1()
        {
            rgen = new Random();

            string playerNm = "";
            int playerHp = 0;
            int playerAtk = 0;
            int playerDf = 0;
            
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            this.graphics.PreferredBackBufferWidth = 1500;
            this.graphics.PreferredBackBufferHeight = 900;
            this.IsMouseVisible = true;
            this.graphics.ApplyChanges();
            mapEnemy1.Move = Movement.Left;
            bool atEnd = false;
            while(atEnd == false)
            {
                string line = output.ReadLine();
                playerNm = line;
                line = output.ReadLine();
                playerHp = int.Parse(line);
                line = output.ReadLine();
                playerAtk = int.Parse(line);
                line = output.ReadLine();
                playerDf = int.Parse(line);
                atEnd = true;
            }

            player = new Player(playerNm, playerHp, playerAtk, playerDf, 0, 1);

            MapEnemy mapEnemy2 = new MapEnemy();
            mapEnemy2.EnemyRec = new Rectangle(400, 300, 50, 50);
            mapEnemy2.Move = Movement.Left;

            MapEnemy mapEnemy3 = new MapEnemy();
            mapEnemy3.EnemyRec = new Rectangle(400, 600, 50, 50);
            mapEnemy3.Move = Movement.Left;

            enemyList1.Add(mapEnemy1);
            enemyList1.Add(mapEnemy2);
            enemyList1.Add(mapEnemy3);

            MapEnemy mapEnemy4 = new MapEnemy();
            mapEnemy4.EnemyRec = new Rectangle(400, 300, 50, 50);
            mapEnemy4.Move = Movement.Left;
            enemyList2.Add(mapEnemy4);

            MapEnemy mapEnemy5 = new MapEnemy();
            mapEnemy5.EnemyRec = new Rectangle(400, 600, 50, 50);
            mapEnemy5.Move = Movement.Left;
            enemyList2.Add(mapEnemy5);

            MapEnemy mapEnemy6 = new MapEnemy();
            mapEnemy6.EnemyRec = new Rectangle(400, 300, 50, 50);
            mapEnemy6.Move = Movement.Left;
            enemyList3.Add(mapEnemy6);

            
            wallRoomList.Add(wallList1);
            wallRoomList.Add(wallList2);
            wallRoomList.Add(wallList3);
            wallRoomList.Add(wallList4);

            level = 1;
            room = 1;
            roomEnemies.Add(enemyList1);
            roomEnemies.Add(enemyList2);
            roomEnemies.Add(enemyList3);
            currentEnemyList = roomEnemies[0];
            currentWalls = wallRoomList[0];
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            font = Content.Load<SpriteFont>("SpriteFont1");
            playerSheet = Content.Load<Texture2D>("Player.jpg");
            wallSheet = Content.Load<Texture2D>("Wall.jpg");
            Rectangle wallRec11 = new Rectangle(0, 0, 50, 900);
            Rectangle wallRec12 = new Rectangle(0, 0, 1500, 50);
            Rectangle wallRec13 = new Rectangle(1450, 0, 50, 900);
            wallList1.Add(wallRec12);
            wallList1.Add(wallRec11);
            wallList1.Add(wallRec13);
            Rectangle wallRec3 = new Rectangle(0, 850, 1500, 50);
            wallList2.Add(wallRec3);
            wallList2.Add(wallRec11);
            wallList3.Add(wallRec3);
            wallList3.Add(wallRec13);
            wallList3.Add(wallRec12);

            wallList4.Add(wallRec3);
            wallList4.Add(wallRec13);
            wallList4.Add(wallRec12);
            wallList4.Add(wallRec11);

            // TODO: use this.Content to load your game content here
            startButton = Content.Load<Texture2D>("rectangle.png");
            MenuButton = Content.Load<Texture2D>("MB.png");
            MenuButtonHover = Content.Load<Texture2D>("MBH.png");
            MenuButtonPressed = Content.Load<Texture2D>("MBP.png");
            Cursor = Content.Load<Texture2D>("Cursor.png");
            stairPic = Content.Load<Texture2D>("New Piskel.png");

            playerStatus = Content.Load<Texture2D>("PlayerStatus.png");
            enemyStatus = Content.Load<Texture2D>("EnemyStatus.png");
            hp = Content.Load<Texture2D>("HP.png");
            xp = Content.Load<Texture2D>("XPBar.png");

            stateMachine = new FSM(MenuButton, font);
            ComInter = new CombatInterface(playerStatus, enemyStatus, hp, xp, font, GraphicsDevice.Viewport.Height, GraphicsDevice.Viewport.Width);

            MapEnemy mapEnemy2 = new MapEnemy();
            MapEnemy mapEnemy3 = new MapEnemy();

            //First Room Area
            Rectangle room11 = new Rectangle(0, 850, 500, 50);
            Rectangle room12 = new Rectangle(1000, 850, 450, 50);
            Rectangle room13 = new Rectangle(0, 250, 950, 50);
            Rectangle room14 = new Rectangle(300, 450, 1050, 50);
            Rectangle room15 = new Rectangle(500, 650, 500, 50);
            Rectangle room16 = new Rectangle(1000, 650, 200, 200);

            //Second Room Area
            Rectangle room21 = new Rectangle(0, 0, 500, 50);
            Rectangle room22 = new Rectangle(1000, 0, 500, 50);
            Rectangle room23 = new Rectangle(600, 200, 500, 300);
            Rectangle room24 = new Rectangle(200, 400, 150, 500);
            Rectangle room25 = new Rectangle(1450, 0, 50, 500);
            Rectangle room26 = new Rectangle(1450, 700, 50, 500);

            //Third Room Area
            Rectangle room31 = new Rectangle(0, 0, 50, 500);
            Rectangle room32 = new Rectangle(0, 700, 50, 500);

            //First Room
            wallList1.Add(wallRec12);
            wallList1.Add(wallRec11);
            wallList1.Add(wallRec13);
            wallList1.Add(room11);
            wallList1.Add(room12);
            wallList1.Add(room13);
            wallList1.Add(room14);
            wallList1.Add(room15);
            wallList1.Add(room16);


            //Second Room
            wallList2.Add(wallRec3);
            wallList2.Add(wallRec11);
            wallList2.Add(room21);
            wallList2.Add(room22);
            wallList2.Add(room23);
            wallList2.Add(room24);
            wallList2.Add(room25);
            wallList2.Add(room26);

            //Third Room
            wallList3.Add(wallRec3);
            wallList3.Add(wallRec13);
            wallList3.Add(wallRec12);
            wallList3.Add(room31);
            wallList3.Add(room32);
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();
            KeyboardState previous = current;
            MouseState previousMouse = mouse;
            KeyboardState kbInput = Keyboard.GetState();
            current = Keyboard.GetState();
            mouse = Mouse.GetState();
            if(stateMachine.state == FSM.gameState.gameOver)
            {
                
            }
            if (stateMachine.state == FSM.gameState.mainMenu)
            {
                if (stateMachine.StartButtonRect.Contains(mouse.Position))
                {
                    if (mouse.LeftButton == ButtonState.Pressed)
                    {
                        stateMachine.state = FSM.gameState.levelUp;
                    }
                }
                if (stateMachine.QuitButtonRect.Contains(mouse.Position))
                {
                    if (mouse.LeftButton == ButtonState.Pressed)
                    {
                        stateMachine.state = FSM.gameState.quitting;
                    }
                }
            }
            if (stateMachine.state == FSM.gameState.game)
            {
                bool moved = false;
                if (kbInput.IsKeyDown(Keys.Up))
                {
                    foreach (Rectangle rec in currentWalls)
                    {
                        if (playerRec.Intersects(rec) == false && moved == false)
                        {
                            playerRec.Y -= 2;
                            moved = true;
                        }
                        if (playerRec.Intersects(rec))
                        {
                            playerRec.Y = playerRec.Y + 6;
                        }
                    }
                }

                if (kbInput.IsKeyDown(Keys.Down))
                {
                    foreach (Rectangle rec in currentWalls)
                    {
                        if (rec.Intersects(playerRec) == false && moved == false)
                        {
                            playerRec.Y += 2;
                            moved = true;
                        }
                        if (rec.Intersects(playerRec))
                        {
                            playerRec.Y = playerRec.Y - 3;
                        }
                    }
                }

                if (kbInput.IsKeyDown(Keys.Right))
                {
                    foreach (Rectangle rec in currentWalls)
                    {
                        if (rec.Intersects(playerRec) == false && moved == false)
                        {
                            playerRec.X += 2;
                            moved = true;
                        }
                        if (rec.Intersects(playerRec))
                        {
                            playerRec.X = playerRec.X - 4;
                        }


                    }
                }

                if (kbInput.IsKeyDown(Keys.Left))
                {
                    foreach (Rectangle rec in currentWalls)
                    {
                        if (rec.Intersects(playerRec) == false && moved == false)
                        {
                            playerRec.X -= 2;
                            moved = true;
                        }
                        if (rec.Intersects(playerRec))
                        {
                            playerRec.X = playerRec.X + 5;
                        }

                    }
                }
                foreach (MapEnemy enemy in currentEnemyList)
                {
                    if (playerRec.Intersects(enemy.EnemyRec) && enemy.Alive == true)
                    {
                        stateMachine.state = FSM.gameState.battle;
                        string type = enemy.Chose(level);
                        int[] stats = enemy.Generate(type);
                        obj.GenerateEnemy(type, stats[0], stats[1], stats[2], stats[3]);
                        obj.GeneratePlayer(player.Health, player.Attack, player.Defense, player.Level, player.Experience);
                        currentTurn = Turn.player;
                        ComInter.PlayerCurrentHp = player.Health;
                        ComInter.PlayerTotalHp = player.MaxHealth;
                        ComInter.EnemyCurrentHp = obj.Enemy.health;
                        ComInter.EnemyTotalHp = ComInter.EnemyCurrentHp;
                        ComInter.TotalXp = player.ToNextLevel;
                        ComInter.CurrentXp = player.Experience;
                        enemyInCombat = enemy;
                    }
                }

                foreach (MapEnemy enemy in currentEnemyList)
                {
                    if (enemy.Move == Movement.Left)
                    {
                        Rectangle rec = enemy.EnemyRec;
                        rec.X--;
                        enemy.EnemyRec = rec;
                    }
                    if (enemy.Move == Movement.Right)
                    {
                        Rectangle rec = enemy.EnemyRec;
                        rec.X++;
                        enemy.EnemyRec = rec;
                    }
                    foreach(Rectangle wall in currentWalls)
                    {
                        if (enemy.EnemyRec.Intersects(wall))
                        {
                            if (enemy.Move == Movement.Left)
                            {
                                enemy.Move = Movement.Right;
                                return;
                            }
                            if (enemy.Move == Movement.Right)
                            {
                                enemy.Move = Movement.Left;
                                return;
                            }
                        }
                    }
                    foreach(Rectangle wall in currentWalls)
                    {
                        if (enemy.EnemyRec.Y > wall.Y + 50 && enemy.EnemyRec.Intersects(wall))
                        {
                            Rectangle rec = enemy.EnemyRec;
                            rec.Y = -20;
                            enemy.EnemyRec = rec;
                        }
                        if (enemy.EnemyRec.Y + 50 < wall.Y && enemy.EnemyRec.Intersects(wall))
                        {
                            Rectangle rec = enemy.EnemyRec;
                            rec.Y = +30;
                            enemy.EnemyRec = rec;
                        }
                    }
                }
                if (playerRec.Y > 880 && kbInput.IsKeyDown(Keys.Down))
                {
                    if (room == 1)
                    {
                        room = 2;
                        playerRec.Y = 0;
                        currentEnemyList = roomEnemies[1];
                        currentWalls = wallRoomList[1];
                    }
                }
                if (playerRec.Y < 0 && kbInput.IsKeyDown(Keys.Up))
                {
                    if (room == 2)
                    {
                        room = 1;
                        playerRec.Y = 900;
                        currentEnemyList = roomEnemies[0];
                        currentWalls = wallRoomList[0];
                    }
                }
                if (playerRec.X > 1500 && kbInput.IsKeyDown(Keys.Right))
                {
                    if (room == 2)
                    {
                        onStairs = true;
                        room = 3;
                        playerRec.X = 0;
                        currentEnemyList = roomEnemies[2];
                        currentWalls = wallRoomList[2];
                    }
                }
                if (playerRec.X < 0 && kbInput.IsKeyDown(Keys.Left))
                {
                    if (room == 3)
                    {
                        room = 2;
                        playerRec.X = 1500;
                        currentEnemyList = roomEnemies[1];
                        currentWalls = wallRoomList[1];
                    }
                }
                if (playerRec.Intersects(stairs) && onStairs == true && room == 3)
                {
                    player.Health = player.MaxHealth;
                    level++;
                    if (level >= 6)
                    {
                        stateMachine.state = FSM.gameState.boss;
                        currentWalls = wallRoomList[3];
                        return;
                    }
                    room = 1;
                    currentEnemyList = roomEnemies[0];
                    currentWalls = wallRoomList[0];
                    foreach (List<MapEnemy> list in roomEnemies)
                    {
                        // Console.WriteLine("If statement reached");
                        // List<MapEnemy> listToChange = list;
                        for (int i = 0; i < list.Count; i++)
                        {
                            list[i] = new MapEnemy();
                            int newX = rgen.Next(400, 1000);
                            int newY = rgen.Next(100, 600);
                            list[i].EnemyRec = new Rectangle(newX, newY, 50, 50);
                            list[i].Alive = true;
                            // Console.WriteLine("Is enemy alive: " + list[i].Alive);
                        }
                    }
                    onStairs = false;
                }

            }
            if (stateMachine.state == FSM.gameState.battle)
            {
                if (!obj.AnyoneDead())
                {
                    if (currentTurn == Turn.player && timer <= 0)
                    {
                        if (current.IsKeyDown(Keys.Enter) && current != previous)
                        {
                            obj.PlayerAttack();
                            currentTurn = Turn.enemy;
                            ComInter.EnemyCurrentHp = obj.Enemy.Health;
                        }
                    }
                    else
                    {
                        obj.EnemyAttack();
                        timer = 10;
                        while (timer >= 0)
                        {
                            System.Threading.Thread.Sleep(200);
                            timer--;
                        }
                        currentTurn = Turn.player;
                        ComInter.PlayerCurrentHp = obj.Player.Health;
                    }
                }
                else
                {
                    if (obj.Enemy.Health <= 0)
                    {
                        ComInter.TotalXp = ComInter.TotalXp + obj.GetXp();
                        foreach (MapEnemy enemy in currentEnemyList)
                        {
                            if (enemy == enemyInCombat)
                            {
                                enemy.Alive = false;
                            }
                        }

                        player.Experience = obj.Player.Experience;
                        player.Health = obj.Player.Health;
                        if (player.LevelUp())
                        {
                            points = 12;
                            stateMachine.state = FSM.gameState.levelUp;
                        }
                        else { stateMachine.state = FSM.gameState.game; }

                        if (obj.Enemy.name == "Boss")
                        {
                            stateMachine.state = FSM.gameState.gameOver;
                        }
                    }
                    if (obj.Player.Health <= 0)
                    {
                        player.Health = obj.Player.Health;
                        stateMachine.state = FSM.gameState.gameOver;
                    }
                    
                }

            }
            if (stateMachine.state == FSM.gameState.boss)
            {
                bool moved = false;
                if (kbInput.IsKeyDown(Keys.Up))
                {
                    foreach (Rectangle rec in currentWalls)
                    {
                        if (playerRec.Intersects(rec) == false && moved == false)
                        {
                            playerRec.Y -= 2;
                            moved = true;
                        }
                        if (playerRec.Intersects(rec))
                        {
                            playerRec.Y = playerRec.Y + 6;
                        }
                    }
                }

                if (kbInput.IsKeyDown(Keys.Down))
                {
                    foreach (Rectangle rec in currentWalls)
                    {
                        if (rec.Intersects(playerRec) == false && moved == false)
                        {
                            playerRec.Y += 2;
                            moved = true;
                        }
                        if (rec.Intersects(playerRec))
                        {
                            playerRec.Y = playerRec.Y - 3;
                        }
                    }
                }

                if (kbInput.IsKeyDown(Keys.Right))
                {
                    foreach (Rectangle rec in currentWalls)
                    {
                        if (rec.Intersects(playerRec) == false && moved == false)
                        {
                            playerRec.X += 2;
                            moved = true;
                        }
                        if (rec.Intersects(playerRec))
                        {
                            playerRec.X = playerRec.X - 4;
                        }


                    }
                }

                if (kbInput.IsKeyDown(Keys.Left))
                {
                    foreach (Rectangle rec in currentWalls)
                    {
                        if (rec.Intersects(playerRec) == false && moved == false)
                        {
                            playerRec.X -= 2;
                            moved = true;
                        }
                        if (rec.Intersects(playerRec))
                        {
                            playerRec.X = playerRec.X + 5;
                        }

                    }
                }
                
                    if (playerRec.Intersects(bossRec))
                    {
                        stateMachine.state = FSM.gameState.battle;
                        obj.GenerateEnemy("Boss", 50, 50, 50, 5);
                        obj.GeneratePlayer(player.Health, player.Attack, player.Defense, player.Level, player.Experience);
                        currentTurn = Turn.player;
                        ComInter.PlayerCurrentHp = player.Health;
                        ComInter.PlayerTotalHp = player.MaxHealth;
                        ComInter.EnemyCurrentHp = obj.Enemy.health;
                        ComInter.EnemyTotalHp = ComInter.EnemyCurrentHp;
                        ComInter.TotalXp = player.ToNextLevel;
                        ComInter.CurrentXp = player.Experience;
                    }
                
                if (playerRec.Y > 880 && kbInput.IsKeyDown(Keys.Down))
                {
                    if (room == 1)
                    {
                        room = 2;
                        playerRec.Y = 0;
                        currentEnemyList = roomEnemies[1];
                        currentWalls = wallRoomList[1];
                    }
                }
                if (playerRec.Y < 0 && kbInput.IsKeyDown(Keys.Up))
                {
                    if (room == 2)
                    {
                        room = 1;
                        playerRec.Y = 900;
                        currentEnemyList = roomEnemies[0];
                        currentWalls = wallRoomList[0];
                    }
                }
                if (playerRec.X > 1500 && kbInput.IsKeyDown(Keys.Right))
                {
                    if (room == 2)
                    {
                        onStairs = true;
                        room = 3;
                        playerRec.X = 0;
                        currentEnemyList = roomEnemies[2];
                        currentWalls = wallRoomList[2];
                    }
                }
                if (playerRec.X < 0 && kbInput.IsKeyDown(Keys.Left))
                {
                    if (room == 3)
                    {
                        room = 2;
                        playerRec.X = 1500;
                        currentEnemyList = roomEnemies[1];
                        currentWalls = wallRoomList[1];
                    }
                }
            }
            if (stateMachine.state == FSM.gameState.levelUp)
            {
                recHealth = new Rectangle(200, 200,50,50);
                recAtk = new Rectangle(200, 400, 50, 50);
                recDef = new Rectangle(200, 600, 50, 50);
                if(mouse.LeftButton == ButtonState.Pressed)
                {
                    if (points != 0)
                    {
                        if (mouse.LeftButton == ButtonState.Pressed && mouse != previousMouse)
                        {
                            if (recHealth.Contains(mouse.Position) && player.MaxHealth < 100)
                            {
                                player.MaxHealth += 1;
                                points--;
                            }
                            if (recAtk.Contains(mouse.Position) && player.Attack < 100)
                            {
                                player.Attack += 1;
                                points--;
                            }
                            if (recDef.Contains(mouse.Position) && player.Defense < 100)
                            {
                                player.Defense += 1;
                                points--;
                            }
                        }
                    }
                    else
                    {
                        player.Health = player.MaxHealth;
                        stateMachine.state = FSM.gameState.game;
                    }
                }
            }
            if (stateMachine.state == FSM.gameState.quitting)
            {
                Exit();
            }
            // TODO: Add your update logic here

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here
            spriteBatch.Begin();
            if(stateMachine.state == FSM.gameState.mainMenu)
            {
                stateMachine.FSMDraw(spriteBatch);
                spriteBatch.Draw(Cursor, new Rectangle(mouse.Position.X, mouse.Position.Y, 20, 20), Color.White);
            }
            if(stateMachine.state == FSM.gameState.game)
            {
                spriteBatch.Draw(playerSheet, playerRec, Color.Blue);
                foreach(MapEnemy enemy in currentEnemyList)
                {
                    if (enemy.Alive == true)
                    {
                        spriteBatch.Draw(playerSheet, enemy.EnemyRec, Color.Red);
                    }
                }
                
                Vector2 wordposit = new Vector2(50, 500);
                spriteBatch.DrawString(font, "Name: " + player.Name + " Health: " + player.Health + " Attack: " + player.Attack + " Defense: " + player.Defense + " Level: " + player.Level + " Exp: " + player.Experience + " To next Level: " + player.ExpToLevel(), wordposit, Color.White);
                foreach (Rectangle rec in currentWalls)
                {
                    spriteBatch.Draw(wallSheet, rec, Color.White);
                }
                if(room == 3)
                {
                    spriteBatch.Draw(stairPic, stairs, Color.White);
                }
                spriteBatch.DrawString(font, "Floor: " + level + " Room: " + room, new Vector2(10, 10), Color.White);
            }
            if(stateMachine.state == FSM.gameState.battle)
            {
                spriteBatch.DrawString(font, obj.GetStats(), new Vector2(0, 100), Color.White);
                ComInter.draw(spriteBatch);
                spriteBatch.DrawString(font, "Enemy type: " + obj.Enemy.name, new Vector2(700, 100), Color.White);
            }
            if(stateMachine.state == FSM.gameState.levelUp)
            {
                spriteBatch.Draw(playerSheet, recHealth, Color.White);
                spriteBatch.DrawString(font, "Max Health: " + player.MaxHealth, new Vector2(recHealth.X + 100, recHealth.Y + 25), Color.White);
                spriteBatch.Draw(playerSheet, recAtk, Color.White);
                spriteBatch.DrawString(font, "Attack: " + player.Attack, new Vector2(recAtk.X + 100, recAtk.Y + 25), Color.White);
                spriteBatch.Draw(playerSheet, recDef, Color.White);
                spriteBatch.DrawString(font, "Defense: " + player.Defense, new Vector2(recDef.X + 100, recDef.Y + 25), Color.White);
            }
            if(stateMachine.state == FSM.gameState.boss)
            {
                spriteBatch.Draw(playerSheet, playerRec, Color.Blue);
                spriteBatch.Draw(playerSheet, bossRec, Color.Red);
                foreach(Rectangle rec in currentWalls)
                {
                    spriteBatch.Draw(wallSheet, rec, Color.White);
                }
            }
            if(stateMachine.state == FSM.gameState.gameOver)
            {
                if(player.Health > 0)
                {
                    spriteBatch.DrawString(font, "You win!", new Vector2(500), Color.White);
                }
                else
                {
                    spriteBatch.DrawString(font, "You lose!", new Vector2(500), Color.White);
                }
            }
            spriteBatch.End();
            base.Draw(gameTime);
        }
    }
}
