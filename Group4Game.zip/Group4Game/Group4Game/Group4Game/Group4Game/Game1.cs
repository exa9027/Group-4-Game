﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;

namespace Group4Game
{
    /// <summary>
    /// Main Game File for Group 4's Game
    /// Enemy is red, Player is blackish-blue, falls are green
    /// Worked on by Ethan Adler, Amit Nemani, and Gabriel Lanna.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        SpriteFont font;
        Texture2D mapSheet;
        Texture2D playerSheet;
        Texture2D wallSheet;
        Texture2D stairPic;
        bool onStairs = true;
        StreamReader output = new StreamReader("..\\..\\..\\..\\..\\ExternalTool\\WindowsFormsApplication1\\bin\\Debug\\info.txt");
        int timer;
        enum GameState { Map, Battle }
        int level;
        int room;
        MapEnemy enemyInCombat;
        List<Rectangle> currentWalls;
        GameState state;
        FSM stateMachine;
        Texture2D startButton;
        Texture2D MenuButton;
        Texture2D MenuButtonPressed;
        Texture2D MenuButtonHover;
        Texture2D Cursor;
        Texture2D CursorHover;
        MouseState mouse;
        Random rgen;
        // combat stuff
        Combat obj = new Combat();
        enum Turn { player, enemy };
        Turn currentTurn;

        Texture2D playerStatus;
        Texture2D enemyStatus;
        Texture2D hp;
        Texture2D xp;
        CombatInterface ComInter;

        KeyboardState current;


        Player player;
        Rectangle playerRec = new Rectangle(60, 60, 50, 50);

        List<List<MapEnemy>> roomEnemies = new List<List<MapEnemy>>();
        MapEnemy mapEnemy1 = new MapEnemy();
        List<MapEnemy> enemyList1 = new List<MapEnemy>();
        List<MapEnemy> enemyList2 = new List<MapEnemy>();
        List<MapEnemy> enemyList3 = new List<MapEnemy>();
        List<MapEnemy> currentEnemyList = new List<MapEnemy>();

        List<List<Rectangle>> wallRoomList = new List<List<Rectangle>>();
        List<Rectangle> wallList1 = new List<Rectangle>();
        List<Rectangle> wallList2 = new List<Rectangle>();
        List<Rectangle> wallList3 = new List<Rectangle>();
        
        Rectangle stairs = new Rectangle(500, 500, 50, 50);

 
        public Game1()
        {
            rgen = new Random();

            string playerNm = "";
            int playerHp = 0;
            int playerAtk = 0;
            int playerDf = 0;
            
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            this.graphics.PreferredBackBufferWidth = 1500;
            this.graphics.PreferredBackBufferHeight = 900;
            this.IsMouseVisible = true;
            this.graphics.ApplyChanges();
            mapEnemy1.Move = Movement.Left;
            bool atEnd = false;
            while(atEnd == false)
            {
                string line = output.ReadLine();
                playerNm = line;
                line = output.ReadLine();
                playerHp = int.Parse(line);
                line = output.ReadLine();
                playerAtk = int.Parse(line);
                line = output.ReadLine();
                playerDf = int.Parse(line);
                atEnd = true;
            }

            player = new Player(playerNm, playerHp, playerAtk, playerDf, 0, 1);

            MapEnemy mapEnemy2 = new MapEnemy();
            mapEnemy2.EnemyRec = new Rectangle(400, 300, 50, 50);
            mapEnemy2.Move = Movement.Left;

            MapEnemy mapEnemy3 = new MapEnemy();
            mapEnemy3.EnemyRec = new Rectangle(200, 600, 50, 50);
            mapEnemy3.Move = Movement.Left;

            enemyList1.Add(mapEnemy1);
            enemyList1.Add(mapEnemy2);
            enemyList1.Add(mapEnemy3);

            MapEnemy mapEnemy4 = new MapEnemy();
            mapEnemy4.EnemyRec = new Rectangle(400, 300, 50, 50);
            mapEnemy4.Move = Movement.Left;
            enemyList2.Add(mapEnemy4);

            MapEnemy mapEnemy5 = new MapEnemy();
            mapEnemy5.EnemyRec = new Rectangle(200, 600, 50, 50);
            mapEnemy5.Move = Movement.Left;
            enemyList2.Add(mapEnemy5);

            MapEnemy mapEnemy6 = new MapEnemy();
            mapEnemy6.EnemyRec = new Rectangle(400, 300, 50, 50);
            mapEnemy6.Move = Movement.Left;
            enemyList3.Add(mapEnemy6);

            wallRoomList.Add(wallList1);
            wallRoomList.Add(wallList2);
            wallRoomList.Add(wallList3);

            level = 1;
            room = 1;
            roomEnemies.Add(enemyList1);
            roomEnemies.Add(enemyList2);
            roomEnemies.Add(enemyList3);
            currentEnemyList = roomEnemies[0];
            currentWalls = wallRoomList[0];
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            font = Content.Load<SpriteFont>("SpriteFont1");
            playerSheet = Content.Load<Texture2D>("Player.jpg");
            wallSheet = Content.Load<Texture2D>("Wall.jpg");
            Rectangle wallRec1 = new Rectangle(0, 0, 200, 50);
            wallList2.Add(wallRec1);
            Rectangle wallRec2 = new Rectangle(0, 50, 50, 200);
            wallList1.Add(wallRec2);
            Rectangle wallRec3 = new Rectangle(400, 400, 100, 100);
            wallList2.Add(wallRec3);
            Rectangle wallRec4 = new Rectangle(800, 100, 50, 200);
            wallList3.Add(wallRec4);

            // TODO: use this.Content to load your game content here
            startButton = Content.Load<Texture2D>("rectangle.png");
            MenuButton = Content.Load<Texture2D>("MB.png");
            MenuButtonHover = Content.Load<Texture2D>("MBH.png");
            MenuButtonPressed = Content.Load<Texture2D>("MBP.png");
            Cursor = Content.Load<Texture2D>("Cursor.png");
            stairPic = Content.Load<Texture2D>("New Piskel.png");

            playerStatus = Content.Load<Texture2D>("PlayerStatus.png");
            enemyStatus = Content.Load<Texture2D>("EnemyStatus.png");
            hp = Content.Load<Texture2D>("HP.png");
            xp = Content.Load<Texture2D>("XPBar.png");

            stateMachine = new FSM(MenuButton, font);
            ComInter = new CombatInterface(playerStatus, enemyStatus, hp, xp, font, GraphicsDevice.Viewport.Height, GraphicsDevice.Viewport.Width);

            MapEnemy mapEnemy2 = new MapEnemy();
            MapEnemy mapEnemy3 = new MapEnemy();


        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();
            KeyboardState previous = current;
            KeyboardState kbInput = Keyboard.GetState();
            current = Keyboard.GetState();
            
            if (stateMachine.state == FSM.gameState.mainMenu)
            {
                mouse = Mouse.GetState();

                if (stateMachine.StartButtonRect.Contains(mouse.Position))
                {
                    if (mouse.LeftButton == ButtonState.Pressed)
                    {
                        stateMachine.state = FSM.gameState.game;
                    }
                }
                if (stateMachine.QuitButtonRect.Contains(mouse.Position))
                {
                    if (mouse.LeftButton == ButtonState.Pressed)
                    {
                        stateMachine.state = FSM.gameState.quitting;
                    }
                }
            }
            if (stateMachine.state == FSM.gameState.game)
            {
                bool moved = false;
                if (kbInput.IsKeyDown(Keys.Up))
                {
                    foreach (Rectangle rec in currentWalls)
                    {
                        if (playerRec.Intersects(rec) == false && moved == false)
                        {
                            playerRec.Y -= 2;
                            moved = true;
                        }
                        if (playerRec.Intersects(rec))
                        {
                            playerRec.Y = playerRec.Y + 6;
                        }
                    }
                }

                if (kbInput.IsKeyDown(Keys.Down))
                {
                    foreach (Rectangle rec in currentWalls)
                    {
                        if (rec.Intersects(playerRec) == false && moved == false)
                        {
                            playerRec.Y += 2;
                            moved = true;
                        }
                        if (rec.Intersects(playerRec))
                        {
                            playerRec.Y = playerRec.Y - 3;
                        }
                    }
                }

                if (kbInput.IsKeyDown(Keys.Right))
                {
                    foreach (Rectangle rec in currentWalls)
                    {
                        if (rec.Intersects(playerRec) == false && moved == false)
                        {
                            playerRec.X += 2;
                            moved = true;
                        }
                        if (rec.Intersects(playerRec))
                        {
                            playerRec.X = playerRec.X - 4;
                        }
                        

                    }
                }

                if (kbInput.IsKeyDown(Keys.Left))
                {
                    foreach (Rectangle rec in currentWalls)
                    {
                        if (rec.Intersects(playerRec) == false && moved == false)
                        {
                            playerRec.X -= 2;
                            moved = true;
                        }
                        if (rec.Intersects(playerRec))
                        {
                            playerRec.X = playerRec.X + 5;
                        }
                        
                    }
                }
                foreach(MapEnemy enemy in currentEnemyList)
                {
                    if (playerRec.Intersects(enemy.EnemyRec) && enemy.Alive == true)
                    {
                        stateMachine.state = FSM.gameState.battle;
                        obj.GenerateEnemy("Enemy", 15, 15, 15, 2);
                        obj.GeneratePlayer(player.Health, player.Attack, player.Defense, player.Level, player.Experience);
                        currentTurn = Turn.player;
                        ComInter.PlayerCurrentHp = player.Health;
                        ComInter.PlayerTotalHp = player.MaxHealth;
                        ComInter.EnemyCurrentHp = obj.Enemy.health;
                        ComInter.EnemyTotalHp = ComInter.EnemyCurrentHp;
                        ComInter.TotalXp = player.ToNextLevel;
                        ComInter.CurrentXp = player.Experience;
                        enemyInCombat = enemy;
                    }
                }

                foreach (MapEnemy enemy in currentEnemyList)
                {
                    if (enemy.Move == Movement.Left)
                    {
                        Rectangle rec = enemy.EnemyRec;
                        rec.X--;
                        enemy.EnemyRec = rec;
                    }
                    if (enemy.Move == Movement.Right)
                    {
                        Rectangle rec = enemy.EnemyRec;
                        rec.X++;
                        enemy.EnemyRec = rec;
                    }

                    if (enemy.Move == Movement.Left && enemy.EnemyRec.X < 100)
                    {
                        enemy.Move = Movement.Right;
                    }
                    if (enemy.Move == Movement.Right && enemy.EnemyRec.X > 600)
                    {
                        enemy.Move = Movement.Left;
                    }
                }
                if(playerRec.Y > 880 && kbInput.IsKeyDown(Keys.Down))
                {
                    if(room == 1)
                    {
                        room = 2;
                        playerRec.Y = 0;
                        currentEnemyList = roomEnemies[1];
                        currentWalls = wallRoomList[1];
                    }
                }
                if (playerRec.Y < 0 && kbInput.IsKeyDown(Keys.Up))
                {
                    if (room == 2)
                    {
                        room = 1;
                        playerRec.Y = 900;
                        currentEnemyList = roomEnemies[0];
                        currentWalls = wallRoomList[0];
                    }
                }
                if(playerRec.X > 1500 && kbInput.IsKeyDown(Keys.Right))
                {
                    if(room == 2)
                    {
                        onStairs = true;
                        room = 3;
                        playerRec.X = 0;
                        currentEnemyList = roomEnemies[2];
                        currentWalls = wallRoomList[2];
                    }
                }
                if(playerRec.X < 0 && kbInput.IsKeyDown(Keys.Left))
                {
                    if (room == 3)
                    {
                        room = 2;
                        playerRec.X = 1500;
                        currentEnemyList = roomEnemies[1];
                        currentWalls = wallRoomList[1];
                    }
                }
                if(playerRec.Intersects(stairs) && onStairs == true)
                {
                    
                    room = 1;
                    currentEnemyList = roomEnemies[0];
                    currentWalls = wallRoomList[0];
                    foreach (List<MapEnemy> list in roomEnemies)
                    {
                        Console.WriteLine("If statement reached");
                        // List<MapEnemy> listToChange = list;
                        for (int i = 0; i < list.Count - 1; i++)
                        {
                            list[i] = new MapEnemy();
                            int newX = rgen.Next(30, 200);
                            int newY = rgen.Next(30, 500);
                            list[i].EnemyRec = new Rectangle(newX, newY, 50, 50);
                            list[i].Alive = true;
                            Console.WriteLine("Is enemy alive: " + list[i].Alive);
                        }
                    }
                    onStairs = false;
                }
                
            }
            if(stateMachine.state == FSM.gameState.battle)
            {
                if (!obj.AnyoneDead())
                {
                    if (currentTurn == Turn.player && timer <= 0)
                    {
                        if (current.IsKeyDown(Keys.Enter) && current != previous)
                        {
                            obj.PlayerAttack();
                            currentTurn = Turn.enemy;
                            ComInter.EnemyCurrentHp = obj.Enemy.Health;
                        }
                    }
                    else
                    {
                        obj.EnemyAttack();
                        timer = 10;
                        while(timer >= 0)
                        {
                            System.Threading.Thread.Sleep(200);
                            timer--;
                        }
                        currentTurn = Turn.player;
                        ComInter.PlayerCurrentHp = obj.Player.Health;
                    }
                }
                else
                {
                    if (obj.Enemy.Health <= 0)
                    {
                        ComInter.TotalXp = ComInter.TotalXp + obj.GetXp();
                        foreach(MapEnemy enemy in currentEnemyList)
                        {
                            if(enemy == enemyInCombat)
                            {
                                enemy.Alive = false;
                            }
                        }

                        player.Experience = obj.Player.Experience;
                        player.Health = obj.Player.Health;
                        player.LevelUp();
                        stateMachine.state = FSM.gameState.game;
                        
                    }
                    if(obj.Player.Health <= 0)
                    {
                        stateMachine.state = FSM.gameState.gameOver;
                    }
                }
                
            }
            if (stateMachine.state == FSM.gameState.quitting)
            {
                Exit();
            }
            // TODO: Add your update logic here

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here
            spriteBatch.Begin();
            if(stateMachine.state == FSM.gameState.mainMenu)
            {
                stateMachine.FSMDraw(spriteBatch);
                spriteBatch.Draw(Cursor, new Rectangle(mouse.Position.X, mouse.Position.Y, 20, 20), Color.White);
            }
            if(stateMachine.state == FSM.gameState.game)
            {
                spriteBatch.Draw(playerSheet, playerRec, Color.Blue);
                foreach(MapEnemy enemy in currentEnemyList)
                {
                    if (enemy.Alive == true)
                    {
                        spriteBatch.Draw(playerSheet, enemy.EnemyRec, Color.Red);
                    }
                }
                
                Vector2 wordposit = new Vector2(50, 500);
                spriteBatch.DrawString(font, "Name: " + player.Name + " Health: " + player.Health + " Attack: " + player.Attack + " Defense: " + player.Defense + " Level: " + player.Level + " Exp: " + player.Experience + " To next Level: " + player.ExpToLevel(), wordposit, Color.White);
                foreach (Rectangle rec in currentWalls)
                {
                    spriteBatch.Draw(wallSheet, rec, Color.White);
                }
                if(room == 3)
                {
                    spriteBatch.Draw(stairPic, stairs, Color.White);
                }
            }
            if(stateMachine.state == FSM.gameState.battle)
            {
                spriteBatch.DrawString(font, obj.GetStats(), new Vector2(0, 100), Color.White);
                ComInter.draw(spriteBatch);
            }
            
            spriteBatch.End();
            base.Draw(gameTime);
        }
    }
}
