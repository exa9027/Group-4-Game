﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group4Game
{
    enum Movement { Right, Left}
    class MapEnemy
    {
        private Movement move;
        public Movement Move
        {
            get { return move; }
            set { move = value; }
        }
        bool alive;
        public bool Alive
        {
            get { return alive; }
            set { alive = value; }
        }
        bool visible;
        public bool Visible
        {
            get { return visible; }
            set { visible = value; }
        }
        public MapEnemy()
        {
            alive = true;
            enemyRec = new Rectangle(500, 100, 50, 50);
        }

        private Rectangle enemyRec;
        public Rectangle EnemyRec
        {
            get { return enemyRec; }
            set { enemyRec = value; }
        }
    }
}
