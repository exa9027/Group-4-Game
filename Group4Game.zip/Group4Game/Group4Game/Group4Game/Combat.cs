﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group4Game
{
    class Combat
    {
        public CombatEnemy Enemy;
        public CombatPlayer Player;

        public void GenerateEnemy(string name, int health, int attack, int defense, int power)
        {
            Enemy = new CombatEnemy(name, health, attack, defense, power);
        }

        public void GeneratePlayer(int health, int attack, int defense, int level, int experience)
        {
            Player = new CombatPlayer(health, attack, defense, level, experience);
        }

        public bool AnyoneDead()
        {
            return (Player.IsDead() || Enemy.IsDead());
        }
        public void PlayerAttack()
        {
            if (!AnyoneDead())
            {
                Enemy.Health -= EnemyTakeDamage();
                if (Enemy.IsDead() == true)
                {
                    int expYield = (200 * Enemy.power) / 7;
                    Player.Experience += expYield;
                    return;
                }
            }
        }

        public void EnemyAttack()
        {
            Player.health -= PlayerTakeDamage();
        }

        public int PlayerTakeDamage()
        {
            int damage = (((((2 * Enemy.power) / 5) + 2) * 30 * (Enemy.attack / Player.defense)) / 50) + 2;
            return damage;
        }
        public int EnemyTakeDamage()
        {
            int damage = (((((2 * Player.level) / 5) + 2) * 30 * (Player.attack / Enemy.defense)) / 50) + 2;
            return damage;
        }
        public string GetStats()
        {
            return ("Enemy HP: " + Enemy.Health + "\nPlayer HP: " + Player.Health + "  Player Exp: " + Player.Experience);
        }
    }
}
