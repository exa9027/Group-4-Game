﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExternalTool
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            nameTbox.Text = null;
            healthTbox.Text = null;
            attackTbox.Text = null;
            defenseTbox.Text = null;
        }

        private void submitBtn_Click(object sender, EventArgs e)
        {
            FileReader obj = new FileReader();

            obj.Save(nameTbox.Text, Int32.Parse(healthTbox.Text), Int32.Parse(attackTbox.Text), Int32.Parse(defenseTbox.Text));
            Application.Exit();
        }
    }
}
