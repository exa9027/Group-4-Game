﻿//CombatEnemy class for "Steve's Quest"

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group4Game
{
    /// <summary>
    /// Controls the enemy during combat.
    /// Worked on by Gabriel Lanna.
    /// </summary>
    class CombatEnemy
    {
        //Set up fields for enemy name, health, attack, defense and power level
        public string name;
        public int health;
        public int attack;
        public int defense;
        public int power;

        //Constructor for Combat enemy class
        public CombatEnemy(string nm, int hp, int atk, int def, int pow)
        {
            name = nm;
            health = hp;
            attack = atk;
            defense = def;
            power = pow;
        }

        //property for Health field
        public int Health
        {
            get { return health; }
            set { health = value; }
        }

        //Method to make sure if enemy is dead or not.
        public bool IsDead()
        {
            //If the enemy health is below 0, return true. If not, return false.
            if (Health <= 0)
            {
                return true;
            }
            return false;
        }

        //Override the ToString method
        public override string ToString()
        {
            //Returns the enemy name, health, attack, defense and power level.
            return "Name: " + name + " Health: " + health + " Attack: " + attack + " Defense: " + " Power: " + power;
        }
    }
}
