﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group4Game
{
    /// <summary>
    /// Sets up the interface for the combat state.
    /// Worked on by Dillon Chan.
    /// </summary>
    class CombatInterface
    {
        string enemyName;
        Texture2D enemySprite;
        Texture2D playerSprite;
        Texture2D playerStatus;
        Texture2D enemyStatus;
        Texture2D hp;
        Texture2D xp;
        SpriteFont font;
        Rectangle playerStatusRect;
        Rectangle enemyStatusRect;
        Rectangle PlayerHpRect;
        Rectangle EnemyHpRect;
        Rectangle xpRect;

        public string EnemyName
        {
            get { return enemyName; }
            set { enemyName = value; }
        }
        public Texture2D PlayerSprite
        {
            get { return playerSprite; }
            set { playerSprite = value; }
        }
        public Texture2D EnemySprite
        {
            get { return enemySprite; }
            set { enemySprite = value; }
        }
        int playerTotalHp; // i only put these fields in so i could show where each of these
        public int PlayerTotalHp
        {
            get { return playerTotalHp; }
            set { playerTotalHp = value; }
        }
        int playerCurrentHp; // would go in the code
        public int PlayerCurrentHp
        {
            get { return playerCurrentHp; }
            set { playerCurrentHp = value; }
        }
        int enemyTotalHp; // however you're getting the variables from the classes
        public int EnemyTotalHp
        {
            get { return enemyTotalHp; }
            set { enemyTotalHp = value; }
        }
        int enemyCurrentHp; // should be done in the draw method
        public int EnemyCurrentHp
        {
            get { return enemyCurrentHp; }
            set { enemyCurrentHp = value; }
        }

        int totalXp; // before any other logic
        public int TotalXp
        {
            get { return totalXp; }
            set { totalXp = value; }
        }
        int currentXp;
        public int CurrentXp
        {
            get { return currentXp; }
            set { currentXp = value; }
        }
        public CombatInterface(Texture2D psprite, Texture2D esprite, Texture2D playerStatusBar, Texture2D enemyStatusBar, Texture2D hpBar, Texture2D xpBar, SpriteFont battleFont, int windowHeight, int windowWidth)
        {
            playerSprite = psprite;
            enemySprite = esprite;
            playerStatus = playerStatusBar;
            enemyStatus = enemyStatusBar;
            hp = hpBar;
            xp = xpBar;
            font = battleFont;
            playerStatusRect = new Rectangle(25, windowHeight - 30 - playerStatus.Height, playerStatus.Width, playerStatus.Height);
            enemyStatusRect = new Rectangle(windowWidth - 25 - enemyStatus.Width, 30, enemyStatus.Width, enemyStatus.Height);
            PlayerHpRect = new Rectangle(33 + 165, windowHeight + 58 - playerStatus.Height, hp.Width, hp.Height);
            EnemyHpRect = new Rectangle(enemyStatusRect.X + 5, enemyStatusRect.Y + 26, hp.Width, hp.Height);
            xpRect = new Rectangle(playerStatusRect.X + 176, playerStatusRect.Y + 154, xp.Width, xp.Height);
        }

        public void draw(SpriteBatch spriteBatch)
        {
            // get your values here

            double playerHPRatio = (double)playerCurrentHp / (double)playerTotalHp;
            int PlayerHpRectWidth = (int)Math.Round(playerHPRatio * hp.Width);
            PlayerHpRect = new Rectangle(PlayerHpRect.X, PlayerHpRect.Y, PlayerHpRectWidth, PlayerHpRect.Height);
            double enemyHPRatio = (double)enemyCurrentHp / (double)enemyTotalHp;
            int EnemyHpRectWidth = (int)Math.Round(enemyHPRatio * hp.Width);
            EnemyHpRect = new Rectangle(EnemyHpRect.X, EnemyHpRect.Y, EnemyHpRectWidth, EnemyHpRect.Height);
            double xpRatio = (double)currentXp / (double)totalXp;
            int xpWidth = (int)Math.Round(xpRatio * xp.Width);
            xpRect = new Rectangle(xpRect.X, xpRect.Y, xpWidth, xpRect.Height);


            spriteBatch.Draw(hp, PlayerHpRect, Color.White);
            spriteBatch.Draw(hp, EnemyHpRect, Color.White);
            spriteBatch.Draw(xp, xpRect, Color.White);
            spriteBatch.Draw(playerSprite, new Rectangle(playerStatusRect.X + 25, playerStatusRect.Y + 25, 149, 149), Color.White);
            if (enemySprite != null)
            {
                spriteBatch.Draw(enemySprite, new Rectangle(enemyStatusRect.X + 777, enemyStatusRect.Y + 26, 149, 149), Color.White);
            }
            spriteBatch.Draw(playerStatus, playerStatusRect, Color.White);
            spriteBatch.Draw(enemyStatus, enemyStatusRect, Color.White);
            spriteBatch.DrawString(font, enemyName, new Vector2(enemyStatusRect.X + 790, enemyStatusRect.Y + 30), Color.Black);


            // draw player level in the box at the bottom and enemy power level in the box at the top
            // you'll need to trial and error that b/c i don't have exact coords (sorry bout that)
        }
    }
}
