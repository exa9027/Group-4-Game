﻿//FSM class for "Steve's Quest"

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna;

namespace Group4Game
{
    /// <summary>
    /// Sets up and controls the main menu and it's interface.
    /// Worked on by Dillon Chan.
    /// </summary>
    class FSM
    {
        //sets up enum for game states
        public enum gameState
        {
            mainMenu,
            game,
            battle,
            levelUp,
            boss,
            bossBattle,
            gameOver,
            quitting
        }

        //set up objects and the initial state to be menu
        public gameState state = gameState.mainMenu;
        public MouseState mouse;
        public Rectangle StartButtonRect;
        public Texture2D Button;
        public SpriteFont font;
        public Rectangle QuitButtonRect;

        //constructor for FSM class, which sets up the start and quit buttons accordin to selected texture and font
        public FSM(Texture2D startButtonTex, SpriteFont fontOfChoice)
        {
            Button = startButtonTex;
            StartButtonRect = new Rectangle(750 - ((startButtonTex.Width + 50 )/2), 500, startButtonTex.Width + 50, startButtonTex.Height);
            font = fontOfChoice;
            QuitButtonRect = StartButtonRect;
            QuitButtonRect.Y = StartButtonRect.Y + 150;
        }

        //currently unused update method for the menu
        public void FSMUpdate()
        {
            //checks what the mouse is doing
            mouse = Mouse.GetState();

            //switch state that checks the game state
            switch (state)
            {
                //if the the game is in the main menu, allow player to click the buttons
                case gameState.mainMenu:
                    if (StartButtonRect.Contains(mouse.Position))
                    {
                        if (mouse.LeftButton == ButtonState.Pressed)
                        {
                            state = gameState.game;
                        }
                    }
                    if (QuitButtonRect.Contains(mouse.Position))
                    {
                        if (mouse.LeftButton == ButtonState.Pressed)
                        {
                            state = gameState.quitting;
                        }
                    }
                    break;
                case gameState.game:
                    break;
            }
        }


        //method to draw the menu
        public void FSMDraw(SpriteBatch spritebatch)
        {
            //check the mouse
            mouse = Mouse.GetState();

            //make sure the player is indexer the menu state
            switch (state)
            {
                case gameState.mainMenu:

                    //draws the play button, making sure it changes color if the mouse is hovering over it.
                    if (StartButtonRect.Contains(mouse.Position))
                    {
                        spritebatch.Draw(Button, StartButtonRect, Color.White);
                        spritebatch.DrawString(font, "Start Game", new Vector2(StartButtonRect.Center.X - 155, StartButtonRect.Center.Y - 35), Color.White);
                    }
                    else
                    {
                        spritebatch.Draw(Button, StartButtonRect, Color.Red);
                        spritebatch.DrawString(font, "Start Game", new Vector2(StartButtonRect.Center.X - 155, StartButtonRect.Center.Y - 35), Color.Red);
                    }

                    //draws the quit button, making sure it changes color if the mouse is hovering over it.
                    if (QuitButtonRect.Contains(mouse.Position))
                    {
                        spritebatch.Draw(Button, QuitButtonRect, Color.White);
                        spritebatch.DrawString(font, "Quit Game", new Vector2(QuitButtonRect.Center.X - 145, QuitButtonRect.Center.Y - 35), Color.White);
                    }
                    else
                    {
                        spritebatch.Draw(Button, QuitButtonRect, Color.Red);
                        spritebatch.DrawString(font, "Quit Game", new Vector2(QuitButtonRect.Center.X - 145, QuitButtonRect.Center.Y - 35), Color.Red);
                    }

                    //debug text to describe what is currently happening on the menu screen
                    spritebatch.DrawString(
                        font,
                        "Mouse Position: (" + mouse.Position.X + ", " + mouse.Position.Y + ")" + "\n" + "Button Width: " + StartButtonRect.Width + "\n" + "Button Height: " + StartButtonRect.Height + "\n" + "Mouse in Rectangle: " + StartButtonRect.Contains(mouse.Position) + "\n" + "Rectangle X and Y: (" + StartButtonRect.X + ", " + StartButtonRect.Y + ")",
                        new Vector2(30, 30),
                        Color.OliveDrab);
                    break;            }
        }
    }
}
