﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group4Game
{
    enum Movement { Right, Left}
    class MapEnemy
    {
        private Movement move;
        public Movement Move
        {
            get { return move; }
            set { move = value; }
        }
        bool alive;
        public bool Alive
        {
            get { return alive; }
            set { alive = value; }
        }
        bool visible;
        public bool Visible
        {
            get { return visible; }
            set { visible = value; }
        }
        public MapEnemy()
        {
            alive = true;
            enemyRec = new Rectangle(500, 100, 50, 50);
        }

        private Rectangle enemyRec;
        public Rectangle EnemyRec
        {
            get { return enemyRec; }
            set { enemyRec = value; }
        }


        public int[] Generate(string enemy)
        {
            int[] stats = new int[5];

            switch (enemy)
            {
                case "Rat":
                    stats = new int[] { 15, 15, 15, 1 };
                    break;
                case "Bat":
                    stats = new int[] { 20, 15, 18, 2 };
                    break;
                case "Snake":
                    stats = new int[] { 25, 19, 14, 3 };
                    break;
                case "Imp":
                    stats = new int[] { 30, 20, 15, 4 };
                    break;
                case "Goblin":
                    stats = new int[] { 0, 0, 0, 0 };
                    break;
                case "Undead":
                    stats = new int[] { 0, 0, 0, 0 };
                    break;
                case "Manticore":
                    stats = new int[] { 0, 0, 0, 0 };
                    break;
                case "Centaur":
                    stats = new int[] { 0, 0, 0, 0 };
                    break;
                case "Cyclops":
                    stats = new int[] { 0, 0, 0, 0 };
                    break;
                case "Ogre":
                    stats = new int[] { 0, 0, 0, 0 };
                    break;
                case "Giant":
                    stats = new int[] { 0, 0, 0, 0 };
                    break;
                case "LesserDragon":
                    stats = new int[] { 0, 0, 0, 0 };
                    break;
                default:
                    stats = new int[] { 0, 0, 0, 0 };
                    break;
            }
            return stats;
        }

        public String Chose(int floor)
        {
            Random rng = new Random();
            int x = rng.Next(0, 10 * floor);
            if (x < 5)
            {
                return "Rat";
            }
            else if (x < 9)
            {
                return "Bat";
            }
            else if (x < 13)
            {
                return "Snake";
            }
            else
            {
                return "Imp";
            }
        }
    }
}
