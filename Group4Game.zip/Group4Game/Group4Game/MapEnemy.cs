﻿//CombatPlayer class for "Steve's Quest"

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group4Game
{
    //Sets up enum for what direction the enemy will be moving
    enum Movement { Right, Left}

    /// <summary>
    /// Controls the Enemy outside of combat and sets them up for combat.
    /// Worked on by Ethan Adler and Gabriel Lanna.
    /// </summary>
    class MapEnemy
    {
        public Texture2D enemySprite;
        public Texture2D EnemySprite
        {
            get { return enemySprite; }
            set { enemySprite = value; }
        }

        //sets up field and property for movement enum
        private Movement move;
        public Movement Move
        {
            get { return move; }
            set { move = value; }
        }

        //sets up field and property for if the enemy is alive
        bool alive;
        public bool Alive
        {
            get { return alive; }
            set { alive = value; }
        }

        //sets up field and property for if the enemy is visible
        bool visible;
        public bool Visible
        {
            get { return visible; }
            set { visible = value; }
        }

        //Constructor for MapEnemy
        public MapEnemy()
        {
            alive = true;
            enemyRec = new Rectangle(500, 100, 50, 50);
        }

        //sets up field and property for if the enemy's Rectangle
        private Rectangle enemyRec;
        public Rectangle EnemyRec
        {
            get { return enemyRec; }
            set { enemyRec = value; }
        }

        //Generate enemy method, which takes in a string for the name of the enemy
        public int[] Generate(string enemy, List<Texture2D> sprites)
        {
            //create array to hold the stats for each enemy
            int[] stats = new int[5];

            //depending on the name of the enemy, return a different array to hold the stats of the enemy
            switch (enemy)
            {
                case "Rat":
                    stats = new int[] { 10, 10, 10, 1 };
                    enemySprite = sprites[0];
                    break;
                case "Bat":
                    stats = new int[] { 15, 12, 13, 2 };
                    enemySprite = sprites[1];
                    break;
                case "Snake":
                    stats = new int[] { 15, 19, 11, 2 };
                    enemySprite = sprites[2];
                    break;
                case "Imp":
                    stats = new int[] { 18, 22, 15, 3 };
                    enemySprite = sprites[3];
                    break;
                case "Book Spirit":
                    stats = new int[] { 20, 20, 20, 3 };
                    enemySprite = sprites[4];
                    break;
                case "Flesh Eater":
                    stats = new int[] { 25, 17, 23, 3 };
                    enemySprite = sprites[5];
                    break;
                case "Slime":
                    stats = new int[] { 23, 27, 25, 4 };
                    enemySprite = sprites[6];
                    break;
                case "Undead Blob":
                    stats = new int[] { 26, 28, 26, 4 };
                    enemySprite = sprites[7];
                    break;
                case "Demon Bat":
                    stats = new int[] { 30, 30, 30, 5 };
                    enemySprite = sprites[8];
                    break;
                case "Undead Adventurer":
                    stats = new int[] { 35, 28, 32, 5 };
                    enemySprite = sprites[9];
                    break;
                case "Spawn of Cthulhu":
                    stats = new int[] { 30, 45, 30, 6 };
                    enemySprite = sprites[10];
                    break;
                case "Lesser Dragon":
                    stats = new int[] { 37, 37, 36, 6 };
                    enemySprite = sprites[11];
                    break;
                default:
                    stats = new int[] { 30, 30, 30, 5 };
                    break;
            }
            //returns the array with the stats of the enemy
            return stats;
        }


        //method to chose what name will be given to the enemy, which takes in an int for what floor the enemy is in
        public String Chose(int floor)
        {
            //create random object
            Random rng = new Random();

            //sets up a control int x to equal a number between 0 and 10^floor
            int x = rng.Next(0, (int)Math.Pow(10, floor));

            //depending on the value of x, return a different enemy name
            if (x < 4)
            {
                return "Rat";
            }
            else if (x < 7)
            {
                return "Bat";
            }
            else if (x < 20)
            {
                return "Snake";
            }
            else if (x < 55)
            {
                return "Imp";
            }
            else if (x < 250)
            {
                return "Book Spirit";
            }
            else if (x < 420)
            {
                return "Flesh Eater";
            }
            else if (x < 800)
            {
                return "Slime";
            }
            else if (x < 2200)
            {
                return "Undead Blob";
            }
            else if (x < 6000)
            {
                return "Demon Bat";
            }
            else if (x < 12000)
            {
                return "Undead Adventurer";
            }
            else if (x < 70000)
            {
                return "Spawn of Cthulhu";
            }
            else
            {
                return "Lesser Dragon";
            }
        }
    }
}
