﻿//CombatPlayer class for "Steve's Quest"

using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group4Game
{
    //Sets up enum for what direction the enemy will be moving
    enum Movement { Right, Left}

    /// <summary>
    /// Controls the Enemy outside of combat and sets them up for combat.
    /// Worked on by Ethan Adler and Gabriel Lanna.
    /// </summary>
    class MapEnemy
    {
        //sets up field and property for movement enum
        private Movement move;
        public Movement Move
        {
            get { return move; }
            set { move = value; }
        }

        //sets up field and property for if the enemy is alive
        bool alive;
        public bool Alive
        {
            get { return alive; }
            set { alive = value; }
        }

        //sets up field and property for if the enemy is visible
        bool visible;
        public bool Visible
        {
            get { return visible; }
            set { visible = value; }
        }

        //Constructor for MapEnemy
        public MapEnemy()
        {
            alive = true;
            enemyRec = new Rectangle(500, 100, 50, 50);
        }

        //sets up field and property for if the enemy's Rectangle
        private Rectangle enemyRec;
        public Rectangle EnemyRec
        {
            get { return enemyRec; }
            set { enemyRec = value; }
        }

        //Generate enemy method, which takes in a string for the name of the enemy
        public int[] Generate(string enemy)
        {
            //create array to hold the stats for each enemy
            int[] stats = new int[5];

            //depending on the name of the enemy, return a different array to hold the stats of the enemy
            switch (enemy)
            {
                case "Rat":
                    stats = new int[] { 10, 10, 10, 1 };
                    break;
                case "Bat":
                    stats = new int[] { 15, 12, 13, 2 };
                    break;
                case "Snake":
                    stats = new int[] { 16, 19, 15, 3 };
                    break;
                case "Imp":
                    stats = new int[] { 19, 24, 17, 4 };
                    break;
                case "Goblin":
                    stats = new int[] { 24, 23, 23, 5 };
                    break;
                case "Undead":
                    stats = new int[] { 32, 20, 28, 6 };
                    break;
                case "Manticore":
                    stats = new int[] { 30, 29, 32, 7 };
                    break;
                case "Centaur":
                    stats = new int[] { 32, 31, 37, 8 };
                    break;
                case "Cyclops":
                    stats = new int[] { 36, 34, 40, 9 };
                    break;
                case "Ogre":
                    stats = new int[] { 45, 32, 43, 10 };
                    break;
                case "Giant":
                    stats = new int[] { 40, 45, 45, 11 };
                    break;
                case "Lesser Dragon":
                    stats = new int[] { 46, 47, 47, 12 };
                    break;
                default:
                    stats = new int[] { 30, 30, 30, 5 };
                    break;
            }
            //returns the array with the stats of the enemy
            return stats;
        }

        //method to chose what name will be given to the enemy, which takes in an int for what floor the enemy is in
        public String Chose(int floor)
        {
            //create random object
            Random rng = new Random();

            //sets up a control int x to equal a number between 0 and 10^floor
            int x = rng.Next(0, (int)Math.Pow(10, floor));

            //depending on the value of x, return a different enemy name
            if (x < 6)
            {
                return "Rat";
            }
            else if (x < 9)
            {
                return "Bat";
            }
            else if (x < 60)
            {
                return "Snake";
            }
            else if (x < 90)
            {
                return "Imp";
            }
            else if (x < 600)
            {
                return "Goblin";
            }
            else if (x < 700)
            {
                return "Undead";
            }
            else if (x < 900)
            {
                return "Manticore";
            }
            else if (x < 4200)
            {
                return "Centaur";
            }
            else if (x < 7090)
            {
                return "Cyclops";
            }
            else if (x < 32000)
            {
                return "Ogre";
            }
            else if (x < 80000)
            {
                return "Giant";
            }
            else
            {
                return "Lesser Dragon";
            }
        }
    }
}
