﻿//CombatPlayer class for "Steve's Quest"

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group4Game
{
    /// <summary>
    /// Controls the player during combat.
    /// Worked on by Gabriel Lanna.
    /// </summary>
    class CombatPlayer
    {
        //Set up fields for health, attack, defense, level and experience points
        public int health;
        public int attack;
        public int defense;
        public int level;
        public int experience;

        //Constructor for Combat Player.
        public CombatPlayer(int hp, int atk, int def, int lvl, int exp)
        {
            health = hp;
            attack = atk;
            defense = def;
            level = lvl;
            experience = exp;
        }

        //property for Health field
        public int Health
        {
            get { return health; }
            set { health = value; }
        }

        //property for Experience field
        public int Experience
        {
            get { return experience; }
            set { experience = value; }
        }

        //Method to make sure if player is dead or not.
        public bool IsDead()
        {
            //If the player health is below 0, return true. If not, return false.
            if (Health <= 0)
            {
                return true;
            }
            return false;
        }

        //Override the ToString method
        public override string ToString()
        {
            //Returns the player health, attack, defense, level and experience.
            return "Health: " + health + " Attack: " + attack + " Defense: " + " Level: " + level + " Exp: " + experience;
        }
    }
}
