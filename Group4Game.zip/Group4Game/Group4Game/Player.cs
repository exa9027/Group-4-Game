﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group4Game
{
    class Player
    {
        //field and property for player name
        string name;
        public string Name
        {
            get { return name; }
        }

        //field and property for player health
        int health;
        public int Health
        {
            get { return health; }
            set { health = value; }
        }

        //field and property for player maximum health
        int maxHealth;
        public int MaxHealth
        {
            get { return maxHealth; }
            set { maxHealth = value; }
        }

        //field and property for player attack
        int attack;
        public int Attack
        {
            get { return attack; }
            set { attack = value; }
        }

        //field and property for player defense
        int defense;
        public int Defense
        {
            get { return defense; }
            set { defense = value; }
        }

        //field and property for player expereince
        int experience;
        public int Experience
        {
            get { return experience; }
            set { experience = value; }
        }

        //field and property for player level
        int level;
        public int Level
        {
            get { return level; }
            set { level = value; }
        }

        //field and property for player expereince needed to level up
        int toNextLevel;
        public int ToNextLevel
        {
            get { return toNextLevel; }
            set { toNextLevel = value; }
        }


        //Constructor for player
        public Player(string nm, int hp, int atk, int def, int exp, int lvl)
        {
            name = nm;
            health = hp;
            maxHealth = hp;
            attack = atk;
            defense = def;
            experience = exp;
            level = lvl;
            //Calls ExpToLevel method as the toNextLevel field
            toNextLevel = ExpToLevel();
        }

        //Calculates experience needed to level up.
        public int ExpToLevel()
        {
            //50 * (2^(player level - 1))
            return 50 * ((int)Math.Pow(2,(Level-1)));
        }

        //Level Up method
        public bool LevelUp()
        {
            //Check if current player experience is higher than ExpToLevel method
            if (Experience >= ExpToLevel())
            {
                //Reduces player experience by ExpToLevel method
                Experience -= ExpToLevel();

                //raises player level by one
                Level += 1;

                //sets up toNextLevel field to equal the new ExpToLevel method.
                toNextLevel = ExpToLevel();

                //returns true
                return true;
            }
            //returns false
            return false;
        }
    }
}
