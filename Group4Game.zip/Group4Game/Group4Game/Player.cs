﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group4Game
{
    class Player
    {
        string name;
        public string Name
        {
            get { return name; }
        }
        int health;
        public int Health
        {
            get { return health; }
            set { health = value; }
        }
        int maxHealth;
        public int MaxHealth
        {
            get { return maxHealth; }
            set { maxHealth = value; }
        }
        int attack;
        public int Attack
        {
            get { return attack; }
            set { attack = value; }
        }
        int defense;
        public int Defense
        {
            get { return defense; }
            set { defense = value; }
        }
        int experience;
        public int Experience
        {
            get { return experience; }
            set { experience = value; }
        }
        int level;
        public int Level
        {
            get { return level; }
            set { level = value; }
        }
        int toNextLevel;
        public int ToNextLevel
        {
            get { return toNextLevel; }
            set { toNextLevel = value; }
        }
        public Player(string nm, int hp, int atk, int def, int exp, int lvl)
        {
            name = nm;
            health = hp;
            maxHealth = hp;
            attack = atk;
            defense = def;
            experience = exp;
            level = lvl;
            toNextLevel = ExpToLevel();
        }

        public int ExpToLevel()
        {
            return 50 * ((int)Math.Pow(2,(Level-1)));
        }

        public bool LevelUp()
        {
            if (Experience >= ExpToLevel())
            {
                Experience -= ExpToLevel();
                // Attack += 15;
                // Defense += 15;
                // MaxHealth += 20;
                Level += 1;
                // Health = MaxHealth;
                toNextLevel = ExpToLevel();
                return true;
            }
            return false;
        }
    }
}
