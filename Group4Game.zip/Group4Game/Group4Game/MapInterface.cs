﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Group4Game
{
    class MapInterface
    {
        /// <summary>
        /// Draws the player status on the map screen
        /// work by Dillon Chan
        /// </summary>

        Texture2D playerStatus;
        Texture2D hp;
        Texture2D xp;
        SpriteFont font;
        Rectangle playerStatusRect;
        Rectangle PlayerHpRect;
        Rectangle xpRect;

        int playerTotalHp;
        public int PlayerTotalHp
        {
            get { return playerTotalHp; }
            set { playerTotalHp = value; }
        }

        int playerCurrentHp;
        public int PlayerCurrentHp
        {
            get { return playerCurrentHp; }
            set { playerCurrentHp = value; }
        }

        int totalXp;
        public int TotalXp
        {
            get { return totalXp; }
            set { totalXp = value; }
        }

        int currentXp;
        public int CurrentXp
        {
            get { return currentXp; }
            set { currentXp = value; }
        }


        public MapInterface(Texture2D statusBar, Texture2D hp, Texture2D xp, SpriteFont battlefont, int windowHeight, int windowWidth)
        {
            playerStatus = statusBar;
            this.hp = hp;
            this.xp = xp;
            font = battlefont;
            playerStatusRect = new Rectangle(20, 895 - playerStatus.Height / 2, playerStatus.Width/2, playerStatus.Height/2);
            PlayerHpRect = new Rectangle(97, 927 - playerStatus.Height/2, hp.Width/2, hp.Height/2);
            xpRect = new Rectangle(97, 960-playerStatus.Height/2, xp.Width/2, xp.Height/2);

        }

        public void draw(SpriteBatch spriteBatch)
        {
            // calculating the lenfth of the HP bar
            double playerHPRatio = (double)playerCurrentHp / (double)playerTotalHp;
            int PlayerHpRectWidth = (int)Math.Round(playerHPRatio *(hp.Width / 2));

            // calculating the lenfth of the XP bar
            double xpRatio = (double)currentXp / (double)totalXp;
            int xpWidth = (int)Math.Round(xpRatio * (xp.Width /2));

            // changing the bars to their new lenghts
            PlayerHpRect = new Rectangle(PlayerHpRect.X, PlayerHpRect.Y, PlayerHpRectWidth, PlayerHpRect.Height);
            xpRect = new Rectangle(xpRect.X, xpRect.Y, xpWidth, xpRect.Height);

            // drawing the sprites
            spriteBatch.Draw(hp, PlayerHpRect, Color.White);
            spriteBatch.Draw(xp, xpRect, Color.White);
            spriteBatch.Draw(playerStatus, playerStatusRect, Color.White);
        }
    }
}
